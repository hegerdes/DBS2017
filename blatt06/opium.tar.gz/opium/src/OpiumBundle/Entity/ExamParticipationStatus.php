<?php

namespace OpiumBundle\Entity;

abstract class ExamParticipationStatus
{
    const ENROLLED = 1;
    const PASSED = 2;
    const FAILED = 3;
}
