<?php

namespace OpiumBundle\Entity;

abstract class ExamType
{
    const WRITTEN = 1;
    const ORAL = 2;
}
