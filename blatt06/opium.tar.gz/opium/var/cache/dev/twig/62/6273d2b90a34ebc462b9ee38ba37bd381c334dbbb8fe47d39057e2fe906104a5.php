<?php

/* OpiumBundle:Index:index.html.twig */
class __TwigTemplate_63c757ba3e3594cbf1e99ba7f96dd9c2b47f9a23cf39f5d61e4570ee86143501 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "OpiumBundle:Index:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'headline' => array($this, 'block_headline'),
            'content_row' => array($this, 'block_content_row'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_131b8955f0e01a04885f38e9846d95601d04a0d48e913819298e4e7d66daa526 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_131b8955f0e01a04885f38e9846d95601d04a0d48e913819298e4e7d66daa526->enter($__internal_131b8955f0e01a04885f38e9846d95601d04a0d48e913819298e4e7d66daa526_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OpiumBundle:Index:index.html.twig"));

        $__internal_32ac77b53e416e036857065bc5f4281e0a244c6e42087dbc92551687391b0a7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32ac77b53e416e036857065bc5f4281e0a244c6e42087dbc92551687391b0a7a->enter($__internal_32ac77b53e416e036857065bc5f4281e0a244c6e42087dbc92551687391b0a7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OpiumBundle:Index:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_131b8955f0e01a04885f38e9846d95601d04a0d48e913819298e4e7d66daa526->leave($__internal_131b8955f0e01a04885f38e9846d95601d04a0d48e913819298e4e7d66daa526_prof);

        
        $__internal_32ac77b53e416e036857065bc5f4281e0a244c6e42087dbc92551687391b0a7a->leave($__internal_32ac77b53e416e036857065bc5f4281e0a244c6e42087dbc92551687391b0a7a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1043759fbf7c3eb96f3edccf0e31e8fc5563c82080ac237f99390fc518108b1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1043759fbf7c3eb96f3edccf0e31e8fc5563c82080ac237f99390fc518108b1b->enter($__internal_1043759fbf7c3eb96f3edccf0e31e8fc5563c82080ac237f99390fc518108b1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ef4fc80916c238951fcc76222ff28946499c0ad1e56bd6289facde3e73cc21ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef4fc80916c238951fcc76222ff28946499c0ad1e56bd6289facde3e73cc21ad->enter($__internal_ef4fc80916c238951fcc76222ff28946499c0ad1e56bd6289facde3e73cc21ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Willkommen";
        
        $__internal_ef4fc80916c238951fcc76222ff28946499c0ad1e56bd6289facde3e73cc21ad->leave($__internal_ef4fc80916c238951fcc76222ff28946499c0ad1e56bd6289facde3e73cc21ad_prof);

        
        $__internal_1043759fbf7c3eb96f3edccf0e31e8fc5563c82080ac237f99390fc518108b1b->leave($__internal_1043759fbf7c3eb96f3edccf0e31e8fc5563c82080ac237f99390fc518108b1b_prof);

    }

    // line 4
    public function block_headline($context, array $blocks = array())
    {
        $__internal_526c882fc363af6de1b3dfe39f86021643e2ae23d9249365123e4219bff83fb9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_526c882fc363af6de1b3dfe39f86021643e2ae23d9249365123e4219bff83fb9->enter($__internal_526c882fc363af6de1b3dfe39f86021643e2ae23d9249365123e4219bff83fb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        $__internal_9f5190cf65e348ffc8e252b4cba2e50f07dc6b1088849c13c7564a921cd12867 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f5190cf65e348ffc8e252b4cba2e50f07dc6b1088849c13c7564a921cd12867->enter($__internal_9f5190cf65e348ffc8e252b4cba2e50f07dc6b1088849c13c7564a921cd12867_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        echo "Willkommen bei OPIuM";
        
        $__internal_9f5190cf65e348ffc8e252b4cba2e50f07dc6b1088849c13c7564a921cd12867->leave($__internal_9f5190cf65e348ffc8e252b4cba2e50f07dc6b1088849c13c7564a921cd12867_prof);

        
        $__internal_526c882fc363af6de1b3dfe39f86021643e2ae23d9249365123e4219bff83fb9->leave($__internal_526c882fc363af6de1b3dfe39f86021643e2ae23d9249365123e4219bff83fb9_prof);

    }

    // line 6
    public function block_content_row($context, array $blocks = array())
    {
        $__internal_c916e980576a1b1f762b7999f9c61ba7694fca616267a771004192b7ed858a3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c916e980576a1b1f762b7999f9c61ba7694fca616267a771004192b7ed858a3b->enter($__internal_c916e980576a1b1f762b7999f9c61ba7694fca616267a771004192b7ed858a3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        $__internal_070a0dd8536beaba143a6c18f8b917fa2c98483cf3ba92e02216f6b530477cdb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_070a0dd8536beaba143a6c18f8b917fa2c98483cf3ba92e02216f6b530477cdb->enter($__internal_070a0dd8536beaba143a6c18f8b917fa2c98483cf3ba92e02216f6b530477cdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        // line 7
        echo "    In diesem Portal können Sie sich zu Prüfungen an- und abmelden sowie ihre Noten einsehen.
";
        
        $__internal_070a0dd8536beaba143a6c18f8b917fa2c98483cf3ba92e02216f6b530477cdb->leave($__internal_070a0dd8536beaba143a6c18f8b917fa2c98483cf3ba92e02216f6b530477cdb_prof);

        
        $__internal_c916e980576a1b1f762b7999f9c61ba7694fca616267a771004192b7ed858a3b->leave($__internal_c916e980576a1b1f762b7999f9c61ba7694fca616267a771004192b7ed858a3b_prof);

    }

    public function getTemplateName()
    {
        return "OpiumBundle:Index:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 7,  78 => 6,  60 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Willkommen{% endblock %}
{% block headline %}Willkommen bei OPIuM{% endblock headline %}

{% block content_row %}
    In diesem Portal können Sie sich zu Prüfungen an- und abmelden sowie ihre Noten einsehen.
{% endblock content_row %}
", "OpiumBundle:Index:index.html.twig", "/home/henne/Desktop/Project/opium/src/OpiumBundle/Resources/views/Index/index.html.twig");
    }
}
