<?php

/* MopaBootstrapBundle::base.html.twig */
class __TwigTemplate_b69e2504004d3fac621a72e5ef8e17a69ffe92e664971c2c00c6d80535238f5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'html_tag' => array($this, 'block_html_tag'),
            'head' => array($this, 'block_head'),
            'head_style' => array($this, 'block_head_style'),
            'head_script' => array($this, 'block_head_script'),
            'title' => array($this, 'block_title'),
            'favicon' => array($this, 'block_favicon'),
            'head_bottom' => array($this, 'block_head_bottom'),
            'body_tag' => array($this, 'block_body_tag'),
            'body_start' => array($this, 'block_body_start'),
            'body' => array($this, 'block_body'),
            'navbar' => array($this, 'block_navbar'),
            'container' => array($this, 'block_container'),
            'container_div_start' => array($this, 'block_container_div_start'),
            'container_class' => array($this, 'block_container_class'),
            'header' => array($this, 'block_header'),
            'content_div_start' => array($this, 'block_content_div_start'),
            'page_header' => array($this, 'block_page_header'),
            'headline' => array($this, 'block_headline'),
            'flashes' => array($this, 'block_flashes'),
            'content_row' => array($this, 'block_content_row'),
            'content' => array($this, 'block_content'),
            'content_content' => array($this, 'block_content_content'),
            'content_sidebar' => array($this, 'block_content_sidebar'),
            'content_div_end' => array($this, 'block_content_div_end'),
            'footer_tag_start' => array($this, 'block_footer_tag_start'),
            'footer' => array($this, 'block_footer'),
            'footer_tag_end' => array($this, 'block_footer_tag_end'),
            'container_div_end' => array($this, 'block_container_div_end'),
            'body_end_before_js' => array($this, 'block_body_end_before_js'),
            'foot_script' => array($this, 'block_foot_script'),
            'foot_script_assetic' => array($this, 'block_foot_script_assetic'),
            'body_end' => array($this, 'block_body_end'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_71a7cc92970e6466dc124791a52ffdd2bf7b070a50d321d11376af22ea822345 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_71a7cc92970e6466dc124791a52ffdd2bf7b070a50d321d11376af22ea822345->enter($__internal_71a7cc92970e6466dc124791a52ffdd2bf7b070a50d321d11376af22ea822345_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle::base.html.twig"));

        $__internal_563461d104ade19b26c8767da8482232afec907930b138f064e64477b1332905 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_563461d104ade19b26c8767da8482232afec907930b138f064e64477b1332905->enter($__internal_563461d104ade19b26c8767da8482232afec907930b138f064e64477b1332905_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle::base.html.twig"));

        // line 1
        $context["__internal_3f1321c8d65c6ce7d888c5c509279e7fd0a960a366bf72bdc44130085ced467c"] = $this->loadTemplate("MopaBootstrapBundle::flash.html.twig", "MopaBootstrapBundle::base.html.twig", 1);
        // line 2
        echo "
<!DOCTYPE html>

";
        // line 5
        $this->displayBlock('html_tag', $context, $blocks);
        // line 8
        echo "
";
        // line 9
        $this->displayBlock('head', $context, $blocks);
        // line 38
        echo "
";
        // line 39
        $this->displayBlock('body_tag', $context, $blocks);
        // line 42
        echo "
";
        // line 43
        $this->displayBlock('body_start', $context, $blocks);
        // line 45
        echo "
";
        // line 46
        $this->displayBlock('body', $context, $blocks);
        // line 126
        echo "
";
        // line 127
        $this->displayBlock('body_end', $context, $blocks);
        // line 129
        echo "</body>
</html>
";
        
        $__internal_71a7cc92970e6466dc124791a52ffdd2bf7b070a50d321d11376af22ea822345->leave($__internal_71a7cc92970e6466dc124791a52ffdd2bf7b070a50d321d11376af22ea822345_prof);

        
        $__internal_563461d104ade19b26c8767da8482232afec907930b138f064e64477b1332905->leave($__internal_563461d104ade19b26c8767da8482232afec907930b138f064e64477b1332905_prof);

    }

    // line 5
    public function block_html_tag($context, array $blocks = array())
    {
        $__internal_a93339e85011c0235b3301dfd797be1ceecd72df39502559c8cfab8108891f3a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a93339e85011c0235b3301dfd797be1ceecd72df39502559c8cfab8108891f3a->enter($__internal_a93339e85011c0235b3301dfd797be1ceecd72df39502559c8cfab8108891f3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "html_tag"));

        $__internal_5e3caaefeb9715fd1c6df5264d88d42e894221e8fb52bc0346233008af0cb3da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e3caaefeb9715fd1c6df5264d88d42e894221e8fb52bc0346233008af0cb3da->enter($__internal_5e3caaefeb9715fd1c6df5264d88d42e894221e8fb52bc0346233008af0cb3da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "html_tag"));

        // line 6
        echo "<html lang=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "locale", array()), "html", null, true);
        echo "\">
";
        
        $__internal_5e3caaefeb9715fd1c6df5264d88d42e894221e8fb52bc0346233008af0cb3da->leave($__internal_5e3caaefeb9715fd1c6df5264d88d42e894221e8fb52bc0346233008af0cb3da_prof);

        
        $__internal_a93339e85011c0235b3301dfd797be1ceecd72df39502559c8cfab8108891f3a->leave($__internal_a93339e85011c0235b3301dfd797be1ceecd72df39502559c8cfab8108891f3a_prof);

    }

    // line 9
    public function block_head($context, array $blocks = array())
    {
        $__internal_ca1afbd6606fd0338475482c352fe37d5f0741ec20cbff5efc557908f58afc5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca1afbd6606fd0338475482c352fe37d5f0741ec20cbff5efc557908f58afc5f->enter($__internal_ca1afbd6606fd0338475482c352fe37d5f0741ec20cbff5efc557908f58afc5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_8eaea6108d871eadff8635b977c8a913bb9d3aaa77d76f0175fd70f37da40854 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8eaea6108d871eadff8635b977c8a913bb9d3aaa77d76f0175fd70f37da40854->enter($__internal_8eaea6108d871eadff8635b977c8a913bb9d3aaa77d76f0175fd70f37da40854_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 10
        echo "<head>
    <meta charset=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
    ";
        // line 12
        $this->displayBlock('head_style', $context, $blocks);
        // line 19
        echo "
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    ";
        // line 22
        $this->displayBlock('head_script', $context, $blocks);
        // line 31
        echo "
    <title>";
        // line 32
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 33
        $this->displayBlock('favicon', $context, $blocks);
        // line 34
        echo "    ";
        $this->displayBlock('head_bottom', $context, $blocks);
        // line 36
        echo "</head>
";
        
        $__internal_8eaea6108d871eadff8635b977c8a913bb9d3aaa77d76f0175fd70f37da40854->leave($__internal_8eaea6108d871eadff8635b977c8a913bb9d3aaa77d76f0175fd70f37da40854_prof);

        
        $__internal_ca1afbd6606fd0338475482c352fe37d5f0741ec20cbff5efc557908f58afc5f->leave($__internal_ca1afbd6606fd0338475482c352fe37d5f0741ec20cbff5efc557908f58afc5f_prof);

    }

    // line 12
    public function block_head_style($context, array $blocks = array())
    {
        $__internal_303939029b972af832ce5f1719785312bf1698d78452ac85ea6d54b13a0fb555 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_303939029b972af832ce5f1719785312bf1698d78452ac85ea6d54b13a0fb555->enter($__internal_303939029b972af832ce5f1719785312bf1698d78452ac85ea6d54b13a0fb555_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_style"));

        $__internal_e359013dcd8c885cdf81434447d15db88bcb302a797b6de04e5dc6bea315906c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e359013dcd8c885cdf81434447d15db88bcb302a797b6de04e5dc6bea315906c->enter($__internal_e359013dcd8c885cdf81434447d15db88bcb302a797b6de04e5dc6bea315906c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_style"));

        // line 13
        echo "    ";
        // line 14
        echo "    ";
        // line 18
        echo "    ";
        
        $__internal_e359013dcd8c885cdf81434447d15db88bcb302a797b6de04e5dc6bea315906c->leave($__internal_e359013dcd8c885cdf81434447d15db88bcb302a797b6de04e5dc6bea315906c_prof);

        
        $__internal_303939029b972af832ce5f1719785312bf1698d78452ac85ea6d54b13a0fb555->leave($__internal_303939029b972af832ce5f1719785312bf1698d78452ac85ea6d54b13a0fb555_prof);

    }

    // line 22
    public function block_head_script($context, array $blocks = array())
    {
        $__internal_37e6b6defdfa840691b23260e118928decd5164b974955a403a54bfa71734edf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37e6b6defdfa840691b23260e118928decd5164b974955a403a54bfa71734edf->enter($__internal_37e6b6defdfa840691b23260e118928decd5164b974955a403a54bfa71734edf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_script"));

        $__internal_bb65d64d433db9cdeb2f49e33e0026581550737334949bebdce66bc917e8bb4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb65d64d433db9cdeb2f49e33e0026581550737334949bebdce66bc917e8bb4c->enter($__internal_bb65d64d433db9cdeb2f49e33e0026581550737334949bebdce66bc917e8bb4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_script"));

        // line 23
        echo "    ";
        // line 30
        echo "    ";
        
        $__internal_bb65d64d433db9cdeb2f49e33e0026581550737334949bebdce66bc917e8bb4c->leave($__internal_bb65d64d433db9cdeb2f49e33e0026581550737334949bebdce66bc917e8bb4c_prof);

        
        $__internal_37e6b6defdfa840691b23260e118928decd5164b974955a403a54bfa71734edf->leave($__internal_37e6b6defdfa840691b23260e118928decd5164b974955a403a54bfa71734edf_prof);

    }

    // line 32
    public function block_title($context, array $blocks = array())
    {
        $__internal_cbd4ac7367684d3de0ccfb3e8080e2f7bdf486180062e1d0f763102189d2ff6c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbd4ac7367684d3de0ccfb3e8080e2f7bdf486180062e1d0f763102189d2ff6c->enter($__internal_cbd4ac7367684d3de0ccfb3e8080e2f7bdf486180062e1d0f763102189d2ff6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_3f90d1122996b1ec9a4963a603e3da7c0ee26d3fc24b36cc256b080b1c3aab2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f90d1122996b1ec9a4963a603e3da7c0ee26d3fc24b36cc256b080b1c3aab2d->enter($__internal_3f90d1122996b1ec9a4963a603e3da7c0ee26d3fc24b36cc256b080b1c3aab2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mopa Bootstrap Bundle";
        
        $__internal_3f90d1122996b1ec9a4963a603e3da7c0ee26d3fc24b36cc256b080b1c3aab2d->leave($__internal_3f90d1122996b1ec9a4963a603e3da7c0ee26d3fc24b36cc256b080b1c3aab2d_prof);

        
        $__internal_cbd4ac7367684d3de0ccfb3e8080e2f7bdf486180062e1d0f763102189d2ff6c->leave($__internal_cbd4ac7367684d3de0ccfb3e8080e2f7bdf486180062e1d0f763102189d2ff6c_prof);

    }

    // line 33
    public function block_favicon($context, array $blocks = array())
    {
        $__internal_0588c2f9fb8f4cb26bd94fd6e4fc1cbe47d284b1f72a8faf5291277d9dc7e247 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0588c2f9fb8f4cb26bd94fd6e4fc1cbe47d284b1f72a8faf5291277d9dc7e247->enter($__internal_0588c2f9fb8f4cb26bd94fd6e4fc1cbe47d284b1f72a8faf5291277d9dc7e247_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "favicon"));

        $__internal_69907c40b6543c3fcc6e83d8f0badc9dcbdb1224042205f18470eec8b39c3f0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69907c40b6543c3fcc6e83d8f0badc9dcbdb1224042205f18470eec8b39c3f0e->enter($__internal_69907c40b6543c3fcc6e83d8f0badc9dcbdb1224042205f18470eec8b39c3f0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "favicon"));

        echo "<link rel=\"shortcut icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />";
        
        $__internal_69907c40b6543c3fcc6e83d8f0badc9dcbdb1224042205f18470eec8b39c3f0e->leave($__internal_69907c40b6543c3fcc6e83d8f0badc9dcbdb1224042205f18470eec8b39c3f0e_prof);

        
        $__internal_0588c2f9fb8f4cb26bd94fd6e4fc1cbe47d284b1f72a8faf5291277d9dc7e247->leave($__internal_0588c2f9fb8f4cb26bd94fd6e4fc1cbe47d284b1f72a8faf5291277d9dc7e247_prof);

    }

    // line 34
    public function block_head_bottom($context, array $blocks = array())
    {
        $__internal_94f3da274966cd90808c812e1d33e7f75eff07b7698a0550448162e54df527ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_94f3da274966cd90808c812e1d33e7f75eff07b7698a0550448162e54df527ac->enter($__internal_94f3da274966cd90808c812e1d33e7f75eff07b7698a0550448162e54df527ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_bottom"));

        $__internal_c3631ee8281d71f4e7669c60a2554c75ff0f6926108d633644f5e941dcbb6ec8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3631ee8281d71f4e7669c60a2554c75ff0f6926108d633644f5e941dcbb6ec8->enter($__internal_c3631ee8281d71f4e7669c60a2554c75ff0f6926108d633644f5e941dcbb6ec8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_bottom"));

        // line 35
        echo "    ";
        
        $__internal_c3631ee8281d71f4e7669c60a2554c75ff0f6926108d633644f5e941dcbb6ec8->leave($__internal_c3631ee8281d71f4e7669c60a2554c75ff0f6926108d633644f5e941dcbb6ec8_prof);

        
        $__internal_94f3da274966cd90808c812e1d33e7f75eff07b7698a0550448162e54df527ac->leave($__internal_94f3da274966cd90808c812e1d33e7f75eff07b7698a0550448162e54df527ac_prof);

    }

    // line 39
    public function block_body_tag($context, array $blocks = array())
    {
        $__internal_cf211a33fc4f835b1d8fdd80415257f32d3c13f72672c13b28d4a58ed2e7bf31 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf211a33fc4f835b1d8fdd80415257f32d3c13f72672c13b28d4a58ed2e7bf31->enter($__internal_cf211a33fc4f835b1d8fdd80415257f32d3c13f72672c13b28d4a58ed2e7bf31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_tag"));

        $__internal_5b9ea91543cbf25a57c143aef2c428ac1d95a825dfe77a7dc46aaab8eef8b738 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b9ea91543cbf25a57c143aef2c428ac1d95a825dfe77a7dc46aaab8eef8b738->enter($__internal_5b9ea91543cbf25a57c143aef2c428ac1d95a825dfe77a7dc46aaab8eef8b738_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_tag"));

        // line 40
        echo "<body>
";
        
        $__internal_5b9ea91543cbf25a57c143aef2c428ac1d95a825dfe77a7dc46aaab8eef8b738->leave($__internal_5b9ea91543cbf25a57c143aef2c428ac1d95a825dfe77a7dc46aaab8eef8b738_prof);

        
        $__internal_cf211a33fc4f835b1d8fdd80415257f32d3c13f72672c13b28d4a58ed2e7bf31->leave($__internal_cf211a33fc4f835b1d8fdd80415257f32d3c13f72672c13b28d4a58ed2e7bf31_prof);

    }

    // line 43
    public function block_body_start($context, array $blocks = array())
    {
        $__internal_1d9f7eedcc130726762db8429994687882de1c18998e6176c7654c6367f4e2b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d9f7eedcc130726762db8429994687882de1c18998e6176c7654c6367f4e2b7->enter($__internal_1d9f7eedcc130726762db8429994687882de1c18998e6176c7654c6367f4e2b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_start"));

        $__internal_8de4b6b0267fca1b1a266e358c8077732605abc7541b0d4d181441b2349841b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8de4b6b0267fca1b1a266e358c8077732605abc7541b0d4d181441b2349841b1->enter($__internal_8de4b6b0267fca1b1a266e358c8077732605abc7541b0d4d181441b2349841b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_start"));

        
        $__internal_8de4b6b0267fca1b1a266e358c8077732605abc7541b0d4d181441b2349841b1->leave($__internal_8de4b6b0267fca1b1a266e358c8077732605abc7541b0d4d181441b2349841b1_prof);

        
        $__internal_1d9f7eedcc130726762db8429994687882de1c18998e6176c7654c6367f4e2b7->leave($__internal_1d9f7eedcc130726762db8429994687882de1c18998e6176c7654c6367f4e2b7_prof);

    }

    // line 46
    public function block_body($context, array $blocks = array())
    {
        $__internal_543c4f3cd833a72695bb95295f215e80c142d59706e1152b9cabfff7e3afef4f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_543c4f3cd833a72695bb95295f215e80c142d59706e1152b9cabfff7e3afef4f->enter($__internal_543c4f3cd833a72695bb95295f215e80c142d59706e1152b9cabfff7e3afef4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9f92ec4e47dfe9b48100a12c80a4a227ff9d1978ed2681baa576daeea4181500 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f92ec4e47dfe9b48100a12c80a4a227ff9d1978ed2681baa576daeea4181500->enter($__internal_9f92ec4e47dfe9b48100a12c80a4a227ff9d1978ed2681baa576daeea4181500_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 47
        echo "    ";
        $this->displayBlock('navbar', $context, $blocks);
        // line 50
        echo "
    ";
        // line 51
        $this->displayBlock('container', $context, $blocks);
        // line 105
        echo "
    ";
        // line 106
        $this->displayBlock('body_end_before_js', $context, $blocks);
        // line 108
        echo "
    ";
        // line 109
        $this->displayBlock('foot_script', $context, $blocks);
        
        $__internal_9f92ec4e47dfe9b48100a12c80a4a227ff9d1978ed2681baa576daeea4181500->leave($__internal_9f92ec4e47dfe9b48100a12c80a4a227ff9d1978ed2681baa576daeea4181500_prof);

        
        $__internal_543c4f3cd833a72695bb95295f215e80c142d59706e1152b9cabfff7e3afef4f->leave($__internal_543c4f3cd833a72695bb95295f215e80c142d59706e1152b9cabfff7e3afef4f_prof);

    }

    // line 47
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_528bd5b40e0434016b1c342309073cf515e3e77209ee5976f615e06e448099bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_528bd5b40e0434016b1c342309073cf515e3e77209ee5976f615e06e448099bb->enter($__internal_528bd5b40e0434016b1c342309073cf515e3e77209ee5976f615e06e448099bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_64a2ec2ea24e15d7c576d2478381647e268596ded0fe2624dd876438c30fbd7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64a2ec2ea24e15d7c576d2478381647e268596ded0fe2624dd876438c30fbd7c->enter($__internal_64a2ec2ea24e15d7c576d2478381647e268596ded0fe2624dd876438c30fbd7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        // line 48
        echo "    <!-- No navbar included here to reduce dependencies, see https://github.com/phiamo/MopaBootstrapSandboxBundle/blob/master/Resources/views/base.html.twig for howto include it -->
    ";
        
        $__internal_64a2ec2ea24e15d7c576d2478381647e268596ded0fe2624dd876438c30fbd7c->leave($__internal_64a2ec2ea24e15d7c576d2478381647e268596ded0fe2624dd876438c30fbd7c_prof);

        
        $__internal_528bd5b40e0434016b1c342309073cf515e3e77209ee5976f615e06e448099bb->leave($__internal_528bd5b40e0434016b1c342309073cf515e3e77209ee5976f615e06e448099bb_prof);

    }

    // line 51
    public function block_container($context, array $blocks = array())
    {
        $__internal_635faec8ac8cfa6151b6ba0186081bc85cdaf56982a6413aa64c5b17bcf5d239 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_635faec8ac8cfa6151b6ba0186081bc85cdaf56982a6413aa64c5b17bcf5d239->enter($__internal_635faec8ac8cfa6151b6ba0186081bc85cdaf56982a6413aa64c5b17bcf5d239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        $__internal_3aabf0c3d26a09755134b1af7aa5ad1a986affcd9bfbec15e223241ffcbbca5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3aabf0c3d26a09755134b1af7aa5ad1a986affcd9bfbec15e223241ffcbbca5e->enter($__internal_3aabf0c3d26a09755134b1af7aa5ad1a986affcd9bfbec15e223241ffcbbca5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        // line 52
        echo "    ";
        $this->displayBlock('container_div_start', $context, $blocks);
        // line 53
        echo "        ";
        $this->displayBlock('header', $context, $blocks);
        // line 55
        echo "
        ";
        // line 56
        $this->displayBlock('content_div_start', $context, $blocks);
        // line 57
        echo "            ";
        $this->displayBlock('page_header', $context, $blocks);
        // line 62
        echo "
            ";
        // line 63
        $this->displayBlock('flashes', $context, $blocks);
        // line 72
        echo "
            ";
        // line 73
        $this->displayBlock('content_row', $context, $blocks);
        // line 89
        echo "
        ";
        // line 90
        $this->displayBlock('content_div_end', $context, $blocks);
        // line 91
        echo "
        ";
        // line 92
        $this->displayBlock('footer_tag_start', $context, $blocks);
        // line 95
        echo "
        ";
        // line 96
        $this->displayBlock('footer', $context, $blocks);
        // line 99
        echo "
        ";
        // line 100
        $this->displayBlock('footer_tag_end', $context, $blocks);
        // line 103
        echo "    ";
        $this->displayBlock('container_div_end', $context, $blocks);
        // line 104
        echo "    ";
        
        $__internal_3aabf0c3d26a09755134b1af7aa5ad1a986affcd9bfbec15e223241ffcbbca5e->leave($__internal_3aabf0c3d26a09755134b1af7aa5ad1a986affcd9bfbec15e223241ffcbbca5e_prof);

        
        $__internal_635faec8ac8cfa6151b6ba0186081bc85cdaf56982a6413aa64c5b17bcf5d239->leave($__internal_635faec8ac8cfa6151b6ba0186081bc85cdaf56982a6413aa64c5b17bcf5d239_prof);

    }

    // line 52
    public function block_container_div_start($context, array $blocks = array())
    {
        $__internal_9710d6f67b5088c7c9d6be42376530fbda83d9eeeedc1ede75b6108c1f390a28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9710d6f67b5088c7c9d6be42376530fbda83d9eeeedc1ede75b6108c1f390a28->enter($__internal_9710d6f67b5088c7c9d6be42376530fbda83d9eeeedc1ede75b6108c1f390a28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container_div_start"));

        $__internal_81c9ca3aa29287b40eb47b2a929ba2d019a8dc6c9a4a8a516ab4658d65621c47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81c9ca3aa29287b40eb47b2a929ba2d019a8dc6c9a4a8a516ab4658d65621c47->enter($__internal_81c9ca3aa29287b40eb47b2a929ba2d019a8dc6c9a4a8a516ab4658d65621c47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container_div_start"));

        echo "<div class=\"";
        $this->displayBlock('container_class', $context, $blocks);
        echo "\">";
        
        $__internal_81c9ca3aa29287b40eb47b2a929ba2d019a8dc6c9a4a8a516ab4658d65621c47->leave($__internal_81c9ca3aa29287b40eb47b2a929ba2d019a8dc6c9a4a8a516ab4658d65621c47_prof);

        
        $__internal_9710d6f67b5088c7c9d6be42376530fbda83d9eeeedc1ede75b6108c1f390a28->leave($__internal_9710d6f67b5088c7c9d6be42376530fbda83d9eeeedc1ede75b6108c1f390a28_prof);

    }

    public function block_container_class($context, array $blocks = array())
    {
        $__internal_d7b94dc08f0c224719126ad6b31aa34481638712b80737df7acdf9d35999e7bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7b94dc08f0c224719126ad6b31aa34481638712b80737df7acdf9d35999e7bb->enter($__internal_d7b94dc08f0c224719126ad6b31aa34481638712b80737df7acdf9d35999e7bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container_class"));

        $__internal_e10e2efa57a1c6412fdee8dfaabce00307d6b8177a0be976684ec5beb8cfd122 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e10e2efa57a1c6412fdee8dfaabce00307d6b8177a0be976684ec5beb8cfd122->enter($__internal_e10e2efa57a1c6412fdee8dfaabce00307d6b8177a0be976684ec5beb8cfd122_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container_class"));

        echo "container";
        
        $__internal_e10e2efa57a1c6412fdee8dfaabce00307d6b8177a0be976684ec5beb8cfd122->leave($__internal_e10e2efa57a1c6412fdee8dfaabce00307d6b8177a0be976684ec5beb8cfd122_prof);

        
        $__internal_d7b94dc08f0c224719126ad6b31aa34481638712b80737df7acdf9d35999e7bb->leave($__internal_d7b94dc08f0c224719126ad6b31aa34481638712b80737df7acdf9d35999e7bb_prof);

    }

    // line 53
    public function block_header($context, array $blocks = array())
    {
        $__internal_a5a618d0851263ef7fb32ba089476c1badb3810e7e47aae6191d49313fb91e43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5a618d0851263ef7fb32ba089476c1badb3810e7e47aae6191d49313fb91e43->enter($__internal_a5a618d0851263ef7fb32ba089476c1badb3810e7e47aae6191d49313fb91e43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_cd653d0c54a480434cb124aa999cd96ec3fed77301c1b1fecff40f25d8c79702 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd653d0c54a480434cb124aa999cd96ec3fed77301c1b1fecff40f25d8c79702->enter($__internal_cd653d0c54a480434cb124aa999cd96ec3fed77301c1b1fecff40f25d8c79702_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 54
        echo "        ";
        
        $__internal_cd653d0c54a480434cb124aa999cd96ec3fed77301c1b1fecff40f25d8c79702->leave($__internal_cd653d0c54a480434cb124aa999cd96ec3fed77301c1b1fecff40f25d8c79702_prof);

        
        $__internal_a5a618d0851263ef7fb32ba089476c1badb3810e7e47aae6191d49313fb91e43->leave($__internal_a5a618d0851263ef7fb32ba089476c1badb3810e7e47aae6191d49313fb91e43_prof);

    }

    // line 56
    public function block_content_div_start($context, array $blocks = array())
    {
        $__internal_70d6bf1f6128302bc9807ee0a469e6e64d4054b4935a1987cdb929b42a1a2cdb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70d6bf1f6128302bc9807ee0a469e6e64d4054b4935a1987cdb929b42a1a2cdb->enter($__internal_70d6bf1f6128302bc9807ee0a469e6e64d4054b4935a1987cdb929b42a1a2cdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_div_start"));

        $__internal_2c72f6624c4e36416ad7fbb45ea5cdf187ac43f78ff129e5fd60a7ac58967d41 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c72f6624c4e36416ad7fbb45ea5cdf187ac43f78ff129e5fd60a7ac58967d41->enter($__internal_2c72f6624c4e36416ad7fbb45ea5cdf187ac43f78ff129e5fd60a7ac58967d41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_div_start"));

        echo "<div class=\"content\">";
        
        $__internal_2c72f6624c4e36416ad7fbb45ea5cdf187ac43f78ff129e5fd60a7ac58967d41->leave($__internal_2c72f6624c4e36416ad7fbb45ea5cdf187ac43f78ff129e5fd60a7ac58967d41_prof);

        
        $__internal_70d6bf1f6128302bc9807ee0a469e6e64d4054b4935a1987cdb929b42a1a2cdb->leave($__internal_70d6bf1f6128302bc9807ee0a469e6e64d4054b4935a1987cdb929b42a1a2cdb_prof);

    }

    // line 57
    public function block_page_header($context, array $blocks = array())
    {
        $__internal_0faf058d6463f5ddbb52733d49c6bf7967c2197e48df77dd8d5230e0623d5730 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0faf058d6463f5ddbb52733d49c6bf7967c2197e48df77dd8d5230e0623d5730->enter($__internal_0faf058d6463f5ddbb52733d49c6bf7967c2197e48df77dd8d5230e0623d5730_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_header"));

        $__internal_b858e13824a67fa598e3921b122e78300350f95479ef85e85cad2f0987b4a1a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b858e13824a67fa598e3921b122e78300350f95479ef85e85cad2f0987b4a1a4->enter($__internal_b858e13824a67fa598e3921b122e78300350f95479ef85e85cad2f0987b4a1a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_header"));

        // line 58
        echo "            <div class=\"page-header\">
                  <h1>";
        // line 59
        $this->displayBlock('headline', $context, $blocks);
        echo "</h1>
            </div>
            ";
        
        $__internal_b858e13824a67fa598e3921b122e78300350f95479ef85e85cad2f0987b4a1a4->leave($__internal_b858e13824a67fa598e3921b122e78300350f95479ef85e85cad2f0987b4a1a4_prof);

        
        $__internal_0faf058d6463f5ddbb52733d49c6bf7967c2197e48df77dd8d5230e0623d5730->leave($__internal_0faf058d6463f5ddbb52733d49c6bf7967c2197e48df77dd8d5230e0623d5730_prof);

    }

    public function block_headline($context, array $blocks = array())
    {
        $__internal_6beba6ae203519c6739015b12579b44db4994c9ec9b6a95d891f1c66609662f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6beba6ae203519c6739015b12579b44db4994c9ec9b6a95d891f1c66609662f1->enter($__internal_6beba6ae203519c6739015b12579b44db4994c9ec9b6a95d891f1c66609662f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        $__internal_56dabc0734d1b24160431d15c15bc42e854295cf7fb299f592cab41d2c27e77f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56dabc0734d1b24160431d15c15bc42e854295cf7fb299f592cab41d2c27e77f->enter($__internal_56dabc0734d1b24160431d15c15bc42e854295cf7fb299f592cab41d2c27e77f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        echo "Mopa Bootstrap Bundle";
        
        $__internal_56dabc0734d1b24160431d15c15bc42e854295cf7fb299f592cab41d2c27e77f->leave($__internal_56dabc0734d1b24160431d15c15bc42e854295cf7fb299f592cab41d2c27e77f_prof);

        
        $__internal_6beba6ae203519c6739015b12579b44db4994c9ec9b6a95d891f1c66609662f1->leave($__internal_6beba6ae203519c6739015b12579b44db4994c9ec9b6a95d891f1c66609662f1_prof);

    }

    // line 63
    public function block_flashes($context, array $blocks = array())
    {
        $__internal_3e55ea4d38f8cd7afe9c01d657b2c10230c91b7dcc27f131e230ceaa445cb053 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e55ea4d38f8cd7afe9c01d657b2c10230c91b7dcc27f131e230ceaa445cb053->enter($__internal_3e55ea4d38f8cd7afe9c01d657b2c10230c91b7dcc27f131e230ceaa445cb053_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashes"));

        $__internal_26c3eba61c3fe54a7b68c7174e30fcc3645b3df4d48a78f6f47addaeacbd393c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26c3eba61c3fe54a7b68c7174e30fcc3645b3df4d48a78f6f47addaeacbd393c->enter($__internal_26c3eba61c3fe54a7b68c7174e30fcc3645b3df4d48a78f6f47addaeacbd393c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flashes"));

        // line 64
        echo "            ";
        if ((twig_length_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "peekAll", array())) > 0)) {
            // line 65
            echo "            <div class=\"row\">
                <div class=\"col-sm-12\">
                ";
            // line 67
            echo $context["__internal_3f1321c8d65c6ce7d888c5c509279e7fd0a960a366bf72bdc44130085ced467c"]->getsession_flash();
            echo "
                </div>
            </div>
            ";
        }
        // line 71
        echo "            ";
        
        $__internal_26c3eba61c3fe54a7b68c7174e30fcc3645b3df4d48a78f6f47addaeacbd393c->leave($__internal_26c3eba61c3fe54a7b68c7174e30fcc3645b3df4d48a78f6f47addaeacbd393c_prof);

        
        $__internal_3e55ea4d38f8cd7afe9c01d657b2c10230c91b7dcc27f131e230ceaa445cb053->leave($__internal_3e55ea4d38f8cd7afe9c01d657b2c10230c91b7dcc27f131e230ceaa445cb053_prof);

    }

    // line 73
    public function block_content_row($context, array $blocks = array())
    {
        $__internal_8d9d2c46490d0c2a628e7b7480018da31482f0f9f2d4b58cf35f6441f34f014f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d9d2c46490d0c2a628e7b7480018da31482f0f9f2d4b58cf35f6441f34f014f->enter($__internal_8d9d2c46490d0c2a628e7b7480018da31482f0f9f2d4b58cf35f6441f34f014f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        $__internal_d9b6f27485787d964b6605b57757fb3d50b58405b01718a119da73777f273815 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9b6f27485787d964b6605b57757fb3d50b58405b01718a119da73777f273815->enter($__internal_d9b6f27485787d964b6605b57757fb3d50b58405b01718a119da73777f273815_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        // line 74
        echo "            <div class=\"row\">
                ";
        // line 75
        $this->displayBlock('content', $context, $blocks);
        // line 87
        echo "            </div>
            ";
        
        $__internal_d9b6f27485787d964b6605b57757fb3d50b58405b01718a119da73777f273815->leave($__internal_d9b6f27485787d964b6605b57757fb3d50b58405b01718a119da73777f273815_prof);

        
        $__internal_8d9d2c46490d0c2a628e7b7480018da31482f0f9f2d4b58cf35f6441f34f014f->leave($__internal_8d9d2c46490d0c2a628e7b7480018da31482f0f9f2d4b58cf35f6441f34f014f_prof);

    }

    // line 75
    public function block_content($context, array $blocks = array())
    {
        $__internal_5048231ce9f7e3399e256f629a5b43f2ce9d5ec5cb535331578fd72a180ecb42 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5048231ce9f7e3399e256f629a5b43f2ce9d5ec5cb535331578fd72a180ecb42->enter($__internal_5048231ce9f7e3399e256f629a5b43f2ce9d5ec5cb535331578fd72a180ecb42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_04ff3f80b0cbe6854de99ddc764a88171b377018d9789f08b7528d5e76cd80d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04ff3f80b0cbe6854de99ddc764a88171b377018d9789f08b7528d5e76cd80d6->enter($__internal_04ff3f80b0cbe6854de99ddc764a88171b377018d9789f08b7528d5e76cd80d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 76
        echo "                <div class=\"col-sm-9\">
                    ";
        // line 77
        $this->displayBlock('content_content', $context, $blocks);
        // line 80
        echo "                </div>
                <div class=\"col-sm-3\">
                    ";
        // line 82
        $this->displayBlock('content_sidebar', $context, $blocks);
        // line 85
        echo "                </div>
                ";
        
        $__internal_04ff3f80b0cbe6854de99ddc764a88171b377018d9789f08b7528d5e76cd80d6->leave($__internal_04ff3f80b0cbe6854de99ddc764a88171b377018d9789f08b7528d5e76cd80d6_prof);

        
        $__internal_5048231ce9f7e3399e256f629a5b43f2ce9d5ec5cb535331578fd72a180ecb42->leave($__internal_5048231ce9f7e3399e256f629a5b43f2ce9d5ec5cb535331578fd72a180ecb42_prof);

    }

    // line 77
    public function block_content_content($context, array $blocks = array())
    {
        $__internal_5bf8930a7f9139509e968d0b47ea3e1e0d8ed928b60d031935846e1cad9cf42f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5bf8930a7f9139509e968d0b47ea3e1e0d8ed928b60d031935846e1cad9cf42f->enter($__internal_5bf8930a7f9139509e968d0b47ea3e1e0d8ed928b60d031935846e1cad9cf42f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_content"));

        $__internal_34dabfc42c05610f96eb17387d438918eba32c3f7d54ed14dd2d529fb0e85859 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34dabfc42c05610f96eb17387d438918eba32c3f7d54ed14dd2d529fb0e85859->enter($__internal_34dabfc42c05610f96eb17387d438918eba32c3f7d54ed14dd2d529fb0e85859_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_content"));

        // line 78
        echo "                    <strong>Hier könnte Ihre Werbung stehen ... </strong>
                    ";
        
        $__internal_34dabfc42c05610f96eb17387d438918eba32c3f7d54ed14dd2d529fb0e85859->leave($__internal_34dabfc42c05610f96eb17387d438918eba32c3f7d54ed14dd2d529fb0e85859_prof);

        
        $__internal_5bf8930a7f9139509e968d0b47ea3e1e0d8ed928b60d031935846e1cad9cf42f->leave($__internal_5bf8930a7f9139509e968d0b47ea3e1e0d8ed928b60d031935846e1cad9cf42f_prof);

    }

    // line 82
    public function block_content_sidebar($context, array $blocks = array())
    {
        $__internal_4e4cc92e4ae132f3541a2866e07198aff138623760ce503a03320d8eec3eee00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e4cc92e4ae132f3541a2866e07198aff138623760ce503a03320d8eec3eee00->enter($__internal_4e4cc92e4ae132f3541a2866e07198aff138623760ce503a03320d8eec3eee00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_sidebar"));

        $__internal_d3a413162e4812e35a72c2b9f58f90b4aec6ac31f401ff611849a38076973a59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3a413162e4812e35a72c2b9f58f90b4aec6ac31f401ff611849a38076973a59->enter($__internal_d3a413162e4812e35a72c2b9f58f90b4aec6ac31f401ff611849a38076973a59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_sidebar"));

        // line 83
        echo "                    <h2>Sidebar</h2>
                    ";
        
        $__internal_d3a413162e4812e35a72c2b9f58f90b4aec6ac31f401ff611849a38076973a59->leave($__internal_d3a413162e4812e35a72c2b9f58f90b4aec6ac31f401ff611849a38076973a59_prof);

        
        $__internal_4e4cc92e4ae132f3541a2866e07198aff138623760ce503a03320d8eec3eee00->leave($__internal_4e4cc92e4ae132f3541a2866e07198aff138623760ce503a03320d8eec3eee00_prof);

    }

    // line 90
    public function block_content_div_end($context, array $blocks = array())
    {
        $__internal_3262907177fcd2bc18dbc4c3ad49fc4c19884edad0ede38eed7cbac7628a90cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3262907177fcd2bc18dbc4c3ad49fc4c19884edad0ede38eed7cbac7628a90cf->enter($__internal_3262907177fcd2bc18dbc4c3ad49fc4c19884edad0ede38eed7cbac7628a90cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_div_end"));

        $__internal_b9f52fe9e7a9a040a8efe9074f35c19cdfe573e1033ebbb2617770e31fce949e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9f52fe9e7a9a040a8efe9074f35c19cdfe573e1033ebbb2617770e31fce949e->enter($__internal_b9f52fe9e7a9a040a8efe9074f35c19cdfe573e1033ebbb2617770e31fce949e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_div_end"));

        echo "</div>";
        
        $__internal_b9f52fe9e7a9a040a8efe9074f35c19cdfe573e1033ebbb2617770e31fce949e->leave($__internal_b9f52fe9e7a9a040a8efe9074f35c19cdfe573e1033ebbb2617770e31fce949e_prof);

        
        $__internal_3262907177fcd2bc18dbc4c3ad49fc4c19884edad0ede38eed7cbac7628a90cf->leave($__internal_3262907177fcd2bc18dbc4c3ad49fc4c19884edad0ede38eed7cbac7628a90cf_prof);

    }

    // line 92
    public function block_footer_tag_start($context, array $blocks = array())
    {
        $__internal_245a3c1eaf1158abd5cee0f83acc42369f327f24b7d2bcae871f4258467d137e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_245a3c1eaf1158abd5cee0f83acc42369f327f24b7d2bcae871f4258467d137e->enter($__internal_245a3c1eaf1158abd5cee0f83acc42369f327f24b7d2bcae871f4258467d137e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer_tag_start"));

        $__internal_7d6c47bcff2ce363264119e93cd1a5cc634a33c34d6e3a81c72637b6c924df18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d6c47bcff2ce363264119e93cd1a5cc634a33c34d6e3a81c72637b6c924df18->enter($__internal_7d6c47bcff2ce363264119e93cd1a5cc634a33c34d6e3a81c72637b6c924df18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer_tag_start"));

        // line 93
        echo "        <footer>
        ";
        
        $__internal_7d6c47bcff2ce363264119e93cd1a5cc634a33c34d6e3a81c72637b6c924df18->leave($__internal_7d6c47bcff2ce363264119e93cd1a5cc634a33c34d6e3a81c72637b6c924df18_prof);

        
        $__internal_245a3c1eaf1158abd5cee0f83acc42369f327f24b7d2bcae871f4258467d137e->leave($__internal_245a3c1eaf1158abd5cee0f83acc42369f327f24b7d2bcae871f4258467d137e_prof);

    }

    // line 96
    public function block_footer($context, array $blocks = array())
    {
        $__internal_bfbfb2e255e2281acd7c1e71a0d40d33920e8c8835de6b87b2c3bcdebecdf841 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bfbfb2e255e2281acd7c1e71a0d40d33920e8c8835de6b87b2c3bcdebecdf841->enter($__internal_bfbfb2e255e2281acd7c1e71a0d40d33920e8c8835de6b87b2c3bcdebecdf841_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_a021857a731a1994ca7cfe20f8f3e4c5720765f5157c30bccb735b9bec815430 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a021857a731a1994ca7cfe20f8f3e4c5720765f5157c30bccb735b9bec815430->enter($__internal_a021857a731a1994ca7cfe20f8f3e4c5720765f5157c30bccb735b9bec815430_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 97
        echo "        <p>&copy; <a href=\"http://www.mohrenweiserpartner.de\" target=\"_blank\">Mohrenweiser & Partner</a> 2011-2015</p>
        ";
        
        $__internal_a021857a731a1994ca7cfe20f8f3e4c5720765f5157c30bccb735b9bec815430->leave($__internal_a021857a731a1994ca7cfe20f8f3e4c5720765f5157c30bccb735b9bec815430_prof);

        
        $__internal_bfbfb2e255e2281acd7c1e71a0d40d33920e8c8835de6b87b2c3bcdebecdf841->leave($__internal_bfbfb2e255e2281acd7c1e71a0d40d33920e8c8835de6b87b2c3bcdebecdf841_prof);

    }

    // line 100
    public function block_footer_tag_end($context, array $blocks = array())
    {
        $__internal_83f6070b40fa65635ef20f2edad47d621268f3e85d585695e2b504649d6039f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83f6070b40fa65635ef20f2edad47d621268f3e85d585695e2b504649d6039f3->enter($__internal_83f6070b40fa65635ef20f2edad47d621268f3e85d585695e2b504649d6039f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer_tag_end"));

        $__internal_7289b922a62a0e89a8315928de052c75744337e60222fd47e527904695f54f2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7289b922a62a0e89a8315928de052c75744337e60222fd47e527904695f54f2d->enter($__internal_7289b922a62a0e89a8315928de052c75744337e60222fd47e527904695f54f2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer_tag_end"));

        // line 101
        echo "        </footer>
        ";
        
        $__internal_7289b922a62a0e89a8315928de052c75744337e60222fd47e527904695f54f2d->leave($__internal_7289b922a62a0e89a8315928de052c75744337e60222fd47e527904695f54f2d_prof);

        
        $__internal_83f6070b40fa65635ef20f2edad47d621268f3e85d585695e2b504649d6039f3->leave($__internal_83f6070b40fa65635ef20f2edad47d621268f3e85d585695e2b504649d6039f3_prof);

    }

    // line 103
    public function block_container_div_end($context, array $blocks = array())
    {
        $__internal_01c41f22f086a2790e8135fda68392a9d18e011b5811c8bc6862fc1613a6065e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01c41f22f086a2790e8135fda68392a9d18e011b5811c8bc6862fc1613a6065e->enter($__internal_01c41f22f086a2790e8135fda68392a9d18e011b5811c8bc6862fc1613a6065e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container_div_end"));

        $__internal_a8c77ae1faa1a88441ce4469f445e1cea3e2853f0ce02e4933337edc43c45cab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8c77ae1faa1a88441ce4469f445e1cea3e2853f0ce02e4933337edc43c45cab->enter($__internal_a8c77ae1faa1a88441ce4469f445e1cea3e2853f0ce02e4933337edc43c45cab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container_div_end"));

        echo "</div><!-- /container -->";
        
        $__internal_a8c77ae1faa1a88441ce4469f445e1cea3e2853f0ce02e4933337edc43c45cab->leave($__internal_a8c77ae1faa1a88441ce4469f445e1cea3e2853f0ce02e4933337edc43c45cab_prof);

        
        $__internal_01c41f22f086a2790e8135fda68392a9d18e011b5811c8bc6862fc1613a6065e->leave($__internal_01c41f22f086a2790e8135fda68392a9d18e011b5811c8bc6862fc1613a6065e_prof);

    }

    // line 106
    public function block_body_end_before_js($context, array $blocks = array())
    {
        $__internal_1e3887262b61856c51736491f0c92a2a586fbeacf7f7024b9ccbef8d6c8b57ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e3887262b61856c51736491f0c92a2a586fbeacf7f7024b9ccbef8d6c8b57ae->enter($__internal_1e3887262b61856c51736491f0c92a2a586fbeacf7f7024b9ccbef8d6c8b57ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_end_before_js"));

        $__internal_5cd0e412182dc557e79b42bd3697f895ef9b542a0ae4a56941cfbb63461fc09d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cd0e412182dc557e79b42bd3697f895ef9b542a0ae4a56941cfbb63461fc09d->enter($__internal_5cd0e412182dc557e79b42bd3697f895ef9b542a0ae4a56941cfbb63461fc09d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_end_before_js"));

        // line 107
        echo "    ";
        
        $__internal_5cd0e412182dc557e79b42bd3697f895ef9b542a0ae4a56941cfbb63461fc09d->leave($__internal_5cd0e412182dc557e79b42bd3697f895ef9b542a0ae4a56941cfbb63461fc09d_prof);

        
        $__internal_1e3887262b61856c51736491f0c92a2a586fbeacf7f7024b9ccbef8d6c8b57ae->leave($__internal_1e3887262b61856c51736491f0c92a2a586fbeacf7f7024b9ccbef8d6c8b57ae_prof);

    }

    // line 109
    public function block_foot_script($context, array $blocks = array())
    {
        $__internal_eb5c69cb779ed7cec730802fdea5927b2c664d9894449861dcbf302eb8bfd412 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb5c69cb779ed7cec730802fdea5927b2c664d9894449861dcbf302eb8bfd412->enter($__internal_eb5c69cb779ed7cec730802fdea5927b2c664d9894449861dcbf302eb8bfd412_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot_script"));

        $__internal_0c19f85d03b22bee5baeff024d7e68bd38617258ebdb6d56b4253ca174de9576 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c19f85d03b22bee5baeff024d7e68bd38617258ebdb6d56b4253ca174de9576->enter($__internal_0c19f85d03b22bee5baeff024d7e68bd38617258ebdb6d56b4253ca174de9576_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot_script"));

        // line 110
        echo "    ";
        // line 114
        echo "    ";
        $this->displayBlock('foot_script_assetic', $context, $blocks);
        // line 117
        echo "
    <script type=\"text/javascript\">
        \$(document).ready(function () {
            \$('[data-toggle=\"tooltip\"]').tooltip();
            \$('[data-toggle=\"popover\"]').popover();
        });
    </script>
    ";
        
        $__internal_0c19f85d03b22bee5baeff024d7e68bd38617258ebdb6d56b4253ca174de9576->leave($__internal_0c19f85d03b22bee5baeff024d7e68bd38617258ebdb6d56b4253ca174de9576_prof);

        
        $__internal_eb5c69cb779ed7cec730802fdea5927b2c664d9894449861dcbf302eb8bfd412->leave($__internal_eb5c69cb779ed7cec730802fdea5927b2c664d9894449861dcbf302eb8bfd412_prof);

    }

    // line 114
    public function block_foot_script_assetic($context, array $blocks = array())
    {
        $__internal_f48acdcdf2472c3462d11f8a8eb84e6738436538e15fa3d54fe08acb6f177c5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f48acdcdf2472c3462d11f8a8eb84e6738436538e15fa3d54fe08acb6f177c5c->enter($__internal_f48acdcdf2472c3462d11f8a8eb84e6738436538e15fa3d54fe08acb6f177c5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot_script_assetic"));

        $__internal_cee42a310f10b037259768d2cf3690f8bd3e229536ac8b2a72799b2c2957eccf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cee42a310f10b037259768d2cf3690f8bd3e229536ac8b2a72799b2c2957eccf->enter($__internal_cee42a310f10b037259768d2cf3690f8bd3e229536ac8b2a72799b2c2957eccf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot_script_assetic"));

        // line 115
        echo "        ";
        // line 116
        echo "    ";
        
        $__internal_cee42a310f10b037259768d2cf3690f8bd3e229536ac8b2a72799b2c2957eccf->leave($__internal_cee42a310f10b037259768d2cf3690f8bd3e229536ac8b2a72799b2c2957eccf_prof);

        
        $__internal_f48acdcdf2472c3462d11f8a8eb84e6738436538e15fa3d54fe08acb6f177c5c->leave($__internal_f48acdcdf2472c3462d11f8a8eb84e6738436538e15fa3d54fe08acb6f177c5c_prof);

    }

    // line 127
    public function block_body_end($context, array $blocks = array())
    {
        $__internal_42b60414861dac9c5bd8cc7000656071a6111cfb676a41262b16760182b3333a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42b60414861dac9c5bd8cc7000656071a6111cfb676a41262b16760182b3333a->enter($__internal_42b60414861dac9c5bd8cc7000656071a6111cfb676a41262b16760182b3333a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_end"));

        $__internal_b13ac4f31a7e8ec00bffa61065b705441092966e8163f247c861fde7084a64df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b13ac4f31a7e8ec00bffa61065b705441092966e8163f247c861fde7084a64df->enter($__internal_b13ac4f31a7e8ec00bffa61065b705441092966e8163f247c861fde7084a64df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_end"));

        
        $__internal_b13ac4f31a7e8ec00bffa61065b705441092966e8163f247c861fde7084a64df->leave($__internal_b13ac4f31a7e8ec00bffa61065b705441092966e8163f247c861fde7084a64df_prof);

        
        $__internal_42b60414861dac9c5bd8cc7000656071a6111cfb676a41262b16760182b3333a->leave($__internal_42b60414861dac9c5bd8cc7000656071a6111cfb676a41262b16760182b3333a_prof);

    }

    public function getTemplateName()
    {
        return "MopaBootstrapBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  844 => 127,  834 => 116,  832 => 115,  823 => 114,  806 => 117,  803 => 114,  801 => 110,  792 => 109,  782 => 107,  773 => 106,  755 => 103,  744 => 101,  735 => 100,  724 => 97,  715 => 96,  704 => 93,  695 => 92,  677 => 90,  666 => 83,  657 => 82,  646 => 78,  637 => 77,  626 => 85,  624 => 82,  620 => 80,  618 => 77,  615 => 76,  606 => 75,  595 => 87,  593 => 75,  590 => 74,  581 => 73,  571 => 71,  564 => 67,  560 => 65,  557 => 64,  548 => 63,  518 => 59,  515 => 58,  506 => 57,  488 => 56,  478 => 54,  469 => 53,  432 => 52,  422 => 104,  419 => 103,  417 => 100,  414 => 99,  412 => 96,  409 => 95,  407 => 92,  404 => 91,  402 => 90,  399 => 89,  397 => 73,  394 => 72,  392 => 63,  389 => 62,  386 => 57,  384 => 56,  381 => 55,  378 => 53,  375 => 52,  366 => 51,  355 => 48,  346 => 47,  336 => 109,  333 => 108,  331 => 106,  328 => 105,  326 => 51,  323 => 50,  320 => 47,  311 => 46,  294 => 43,  283 => 40,  274 => 39,  264 => 35,  255 => 34,  235 => 33,  217 => 32,  207 => 30,  205 => 23,  196 => 22,  186 => 18,  184 => 14,  182 => 13,  173 => 12,  162 => 36,  159 => 34,  157 => 33,  153 => 32,  150 => 31,  148 => 22,  143 => 19,  141 => 12,  137 => 11,  134 => 10,  125 => 9,  112 => 6,  103 => 5,  91 => 129,  89 => 127,  86 => 126,  84 => 46,  81 => 45,  79 => 43,  76 => 42,  74 => 39,  71 => 38,  69 => 9,  66 => 8,  64 => 5,  59 => 2,  57 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% from 'MopaBootstrapBundle::flash.html.twig' import session_flash %}

<!DOCTYPE html>

{% block html_tag %}
<html lang=\"{{ app.request.locale }}\">
{% endblock html_tag %}

{% block head %}
<head>
    <meta charset=\"{{ _charset }}\" />
    {% block head_style %}
    {# Override this block to add your own files! #}
    {# To use this without less or sass use the base.html.twig template as your base
     # Be sure you understand whats going on: have a look into
     # https://github.com/phiamo/MopaBootstrapBundle/blob/master/Resources/doc/css-vs-less.md
     #}
    {% endblock head_style %}

    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    {% block head_script %}
    {# Overwrite this block to add your own js here, to get them generated into final files
    {% javascripts
        'http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js'
    %}
        <script type=\"text/javascript\" src=\"{{ asset_url }}\"></script>
    {% endjavascripts %}
     #}
    {% endblock head_script %}

    <title>{% block title %}Mopa Bootstrap Bundle{% endblock title %}</title>
    {% block favicon %}<link rel=\"shortcut icon\" href=\"{{ asset('favicon.ico') }}\" />{% endblock %}
    {% block head_bottom %}
    {% endblock head_bottom %}
</head>
{% endblock head %}

{% block body_tag %}
<body>
{% endblock body_tag %}

{% block body_start %}
{% endblock body_start %}

{% block body %}
    {% block navbar %}
    <!-- No navbar included here to reduce dependencies, see https://github.com/phiamo/MopaBootstrapSandboxBundle/blob/master/Resources/views/base.html.twig for howto include it -->
    {% endblock navbar %}

    {% block container %}
    {% block container_div_start %}<div class=\"{% block container_class %}container{% endblock container_class %}\">{% endblock container_div_start %}
        {% block header %}
        {% endblock header %}

        {% block content_div_start %}<div class=\"content\">{% endblock content_div_start %}
            {% block page_header %}
            <div class=\"page-header\">
                  <h1>{% block headline %}Mopa Bootstrap Bundle{% endblock headline %}</h1>
            </div>
            {% endblock page_header %}

            {% block flashes %}
            {% if app.session.flashbag.peekAll|length > 0 %}
            <div class=\"row\">
                <div class=\"col-sm-12\">
                {{ session_flash() }}
                </div>
            </div>
            {% endif %}
            {% endblock flashes %}

            {% block content_row %}
            <div class=\"row\">
                {% block content %}
                <div class=\"col-sm-9\">
                    {% block content_content %}
                    <strong>Hier könnte Ihre Werbung stehen ... </strong>
                    {% endblock content_content %}
                </div>
                <div class=\"col-sm-3\">
                    {% block content_sidebar %}
                    <h2>Sidebar</h2>
                    {% endblock content_sidebar %}
                </div>
                {% endblock content %}
            </div>
            {% endblock content_row %}

        {% block content_div_end %}</div>{% endblock content_div_end %}

        {% block footer_tag_start %}
        <footer>
        {% endblock footer_tag_start %}

        {% block footer %}
        <p>&copy; <a href=\"http://www.mohrenweiserpartner.de\" target=\"_blank\">Mohrenweiser & Partner</a> 2011-2015</p>
        {% endblock footer %}

        {% block footer_tag_end %}
        </footer>
        {% endblock footer_tag_end %}
    {% block container_div_end %}</div><!-- /container -->{% endblock container_div_end %}
    {% endblock container %}

    {% block body_end_before_js %}
    {% endblock body_end_before_js %}

    {% block foot_script %}
    {# To only use a subset or add more js overwrite and copy paste this block
    To speed up page loads save a copy of jQuery in your project and override this block to include the correct path
    Otherwise the regeneration is done on every load in dev more with use_controller: true
     #}
    {% block foot_script_assetic %}
        {# Please add the javascripts you need in your project #}
    {% endblock foot_script_assetic %}

    <script type=\"text/javascript\">
        \$(document).ready(function () {
            \$('[data-toggle=\"tooltip\"]').tooltip();
            \$('[data-toggle=\"popover\"]').popover();
        });
    </script>
    {% endblock foot_script %}
{% endblock body %}

{% block body_end %}
{% endblock body_end %}
</body>
</html>
", "MopaBootstrapBundle::base.html.twig", "/home/henne/Desktop/Project/opium/vendor/mopa/bootstrap-bundle/Mopa/Bundle/BootstrapBundle/Resources/views/base.html.twig");
    }
}
