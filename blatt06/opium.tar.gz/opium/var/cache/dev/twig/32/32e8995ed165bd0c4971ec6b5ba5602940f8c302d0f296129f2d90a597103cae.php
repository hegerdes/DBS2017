<?php

/* MopaBootstrapBundle::macros.html.twig */
class __TwigTemplate_709941a030413bef01bc62a7e3224150b02033aa8f49f38325005e368a57fff8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5a7733ca1f56b886a6844b1870d6395940c96d7c78f0c292ef238d1db827400a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a7733ca1f56b886a6844b1870d6395940c96d7c78f0c292ef238d1db827400a->enter($__internal_5a7733ca1f56b886a6844b1870d6395940c96d7c78f0c292ef238d1db827400a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle::macros.html.twig"));

        $__internal_598859e80a60c3c75fb2b0e654ca936c0f19ce264a09e7724ee8f7fadf0d6cf6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_598859e80a60c3c75fb2b0e654ca936c0f19ce264a09e7724ee8f7fadf0d6cf6->enter($__internal_598859e80a60c3c75fb2b0e654ca936c0f19ce264a09e7724ee8f7fadf0d6cf6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle::macros.html.twig"));

        // line 4
        echo "
";
        // line 9
        echo "

";
        
        $__internal_5a7733ca1f56b886a6844b1870d6395940c96d7c78f0c292ef238d1db827400a->leave($__internal_5a7733ca1f56b886a6844b1870d6395940c96d7c78f0c292ef238d1db827400a_prof);

        
        $__internal_598859e80a60c3c75fb2b0e654ca936c0f19ce264a09e7724ee8f7fadf0d6cf6->leave($__internal_598859e80a60c3c75fb2b0e654ca936c0f19ce264a09e7724ee8f7fadf0d6cf6_prof);

    }

    // line 1
    public function getbadge($__text__ = null, $__use_raw__ = null, $__class__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "text" => $__text__,
            "use_raw" => $__use_raw__,
            "class" => $__class__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_dcfa5700b98f15d9418b65ffc9f56c848d964f6c1c027f9332a7d0cf4eb463fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_dcfa5700b98f15d9418b65ffc9f56c848d964f6c1c027f9332a7d0cf4eb463fa->enter($__internal_dcfa5700b98f15d9418b65ffc9f56c848d964f6c1c027f9332a7d0cf4eb463fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "badge"));

            $__internal_8e18b463bb5b016da9c1cd3688adc66fc8d139041b973daa4bbff11438f0c1ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_8e18b463bb5b016da9c1cd3688adc66fc8d139041b973daa4bbff11438f0c1ef->enter($__internal_8e18b463bb5b016da9c1cd3688adc66fc8d139041b973daa4bbff11438f0c1ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "badge"));

            // line 2
            echo "<span class=\"badge";
            echo twig_escape_filter($this->env, ((((array_key_exists("class", $context)) ? (_twig_default_filter(($context["class"] ?? $this->getContext($context, "class")), false)) : (false))) ? ((" " . ($context["class"] ?? $this->getContext($context, "class")))) : ("")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, ((((array_key_exists("use_raw", $context)) ? (_twig_default_filter(($context["use_raw"] ?? $this->getContext($context, "use_raw")), false)) : (false))) ? (($context["text"] ?? $this->getContext($context, "text"))) : (($context["text"] ?? $this->getContext($context, "text")))), "html", null, true);
            echo "</span>
";
            
            $__internal_8e18b463bb5b016da9c1cd3688adc66fc8d139041b973daa4bbff11438f0c1ef->leave($__internal_8e18b463bb5b016da9c1cd3688adc66fc8d139041b973daa4bbff11438f0c1ef_prof);

            
            $__internal_dcfa5700b98f15d9418b65ffc9f56c848d964f6c1c027f9332a7d0cf4eb463fa->leave($__internal_dcfa5700b98f15d9418b65ffc9f56c848d964f6c1c027f9332a7d0cf4eb463fa_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    // line 5
    public function getlabel($__text__ = null, $__type__ = null, $__use_raw__ = null, $__block__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "text" => $__text__,
            "type" => $__type__,
            "use_raw" => $__use_raw__,
            "block" => $__block__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_d195bbd1554be2c1b2c40437eb8fa8780377d334698067ab55526adebe6e6db3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_d195bbd1554be2c1b2c40437eb8fa8780377d334698067ab55526adebe6e6db3->enter($__internal_d195bbd1554be2c1b2c40437eb8fa8780377d334698067ab55526adebe6e6db3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "label"));

            $__internal_8c97598b2770d7ab50be8592bdda7923be132498dc818245fb3e34a60a948e36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_8c97598b2770d7ab50be8592bdda7923be132498dc818245fb3e34a60a948e36->enter($__internal_8c97598b2770d7ab50be8592bdda7923be132498dc818245fb3e34a60a948e36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "label"));

            // line 6
            $context["tag"] = ((((array_key_exists("block", $context)) ? (_twig_default_filter(($context["block"] ?? $this->getContext($context, "block")), false)) : (false))) ? ("div") : ("span"));
            // line 7
            echo "<";
            echo twig_escape_filter($this->env, ($context["tag"] ?? $this->getContext($context, "tag")), "html", null, true);
            echo " class=\"label ";
            echo twig_escape_filter($this->env, ((((array_key_exists("type", $context)) ? (_twig_default_filter(($context["type"] ?? $this->getContext($context, "type")), false)) : (false))) ? (("label-" . ($context["type"] ?? $this->getContext($context, "type")))) : ("label-default")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, ((((array_key_exists("use_raw", $context)) ? (_twig_default_filter(($context["use_raw"] ?? $this->getContext($context, "use_raw")), false)) : (false))) ? (($context["text"] ?? $this->getContext($context, "text"))) : (($context["text"] ?? $this->getContext($context, "text")))), "html", null, true);
            echo "</";
            echo twig_escape_filter($this->env, ($context["tag"] ?? $this->getContext($context, "tag")), "html", null, true);
            echo ">
";
            
            $__internal_8c97598b2770d7ab50be8592bdda7923be132498dc818245fb3e34a60a948e36->leave($__internal_8c97598b2770d7ab50be8592bdda7923be132498dc818245fb3e34a60a948e36_prof);

            
            $__internal_d195bbd1554be2c1b2c40437eb8fa8780377d334698067ab55526adebe6e6db3->leave($__internal_d195bbd1554be2c1b2c40437eb8fa8780377d334698067ab55526adebe6e6db3_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    // line 11
    public function getprogressBar($__class__ = null, $__width__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "class" => $__class__,
            "width" => $__width__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_7ed695c42b4a95a36910e7739b7c374f25cb1d07202b6c0e53a43a12aa046e5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_7ed695c42b4a95a36910e7739b7c374f25cb1d07202b6c0e53a43a12aa046e5c->enter($__internal_7ed695c42b4a95a36910e7739b7c374f25cb1d07202b6c0e53a43a12aa046e5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "progressBar"));

            $__internal_e6062c2be93d61b68154d7b4a01b80d26fcc06b88a3342320b097feb1b02ba6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_e6062c2be93d61b68154d7b4a01b80d26fcc06b88a3342320b097feb1b02ba6a->enter($__internal_e6062c2be93d61b68154d7b4a01b80d26fcc06b88a3342320b097feb1b02ba6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "progressBar"));

            // line 12
            echo "<div class=\"progress ";
            echo twig_escape_filter($this->env, ((array_key_exists("class", $context)) ? (_twig_default_filter(($context["class"] ?? $this->getContext($context, "class")), "")) : ("")), "html", null, true);
            echo "\">
    <div class=\"bar\" style=\"width: ";
            // line 13
            echo twig_escape_filter($this->env, ((array_key_exists("width", $context)) ? (_twig_default_filter(($context["width"] ?? $this->getContext($context, "width")), 0)) : (0)), "html", null, true);
            echo "%;\"></div>
</div>
";
            
            $__internal_e6062c2be93d61b68154d7b4a01b80d26fcc06b88a3342320b097feb1b02ba6a->leave($__internal_e6062c2be93d61b68154d7b4a01b80d26fcc06b88a3342320b097feb1b02ba6a_prof);

            
            $__internal_7ed695c42b4a95a36910e7739b7c374f25cb1d07202b6c0e53a43a12aa046e5c->leave($__internal_7ed695c42b4a95a36910e7739b7c374f25cb1d07202b6c0e53a43a12aa046e5c_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "MopaBootstrapBundle::macros.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 13,  158 => 12,  139 => 11,  109 => 7,  107 => 6,  86 => 5,  60 => 2,  40 => 1,  28 => 9,  25 => 4,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro badge(text, use_raw, class) %}
<span class=\"badge{{ class|default(false)?' '~class:'' }}\">{{ use_raw|default(false) ? text|raw : text }}</span>
{% endmacro %}

{% macro label(text, type, use_raw, block) %}
{% set tag = block|default(false) ? 'div' : 'span' %}
<{{ tag }} class=\"label {{ type|default(false) ? 'label-'~type: 'label-default' }}\">{{ use_raw|default(false) ? text|raw : text }}</{{ tag }}>
{% endmacro %}


{% macro progressBar(class, width) %}
<div class=\"progress {{ class|default('') }}\">
    <div class=\"bar\" style=\"width: {{ width|default(0) }}%;\"></div>
</div>
{% endmacro %}
", "MopaBootstrapBundle::macros.html.twig", "/home/henne/Desktop/Project/opium/vendor/mopa/bootstrap-bundle/Mopa/Bundle/BootstrapBundle/Resources/views/macros.html.twig");
    }
}
