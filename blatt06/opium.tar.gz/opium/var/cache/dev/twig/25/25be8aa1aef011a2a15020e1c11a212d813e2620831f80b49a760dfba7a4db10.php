<?php

/* @FOSUser/Security/login.html.twig */
class __TwigTemplate_34c0428db31c588f050166fc045b1da47dd67a6399f97468bcd8268cb7b7192b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "@FOSUser/Security/login.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'headline' => array($this, 'block_headline'),
            'content_row' => array($this, 'block_content_row'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_098be161a6ff02c0160135c258fd4e92fa731f7b74209190dfd0ae2827e8d4c6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_098be161a6ff02c0160135c258fd4e92fa731f7b74209190dfd0ae2827e8d4c6->enter($__internal_098be161a6ff02c0160135c258fd4e92fa731f7b74209190dfd0ae2827e8d4c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $__internal_0b9a7594e572cdef9b034d6c4b282b447019b495eac770c90e2bf6147c0be882 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b9a7594e572cdef9b034d6c4b282b447019b495eac770c90e2bf6147c0be882->enter($__internal_0b9a7594e572cdef9b034d6c4b282b447019b495eac770c90e2bf6147c0be882_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        // line 3
        $context["__internal_676875d968d0b32f09406800934c8c97cbfc97aaadb628cd7ac61fe0b8494a03"] = $this->loadTemplate("MopaBootstrapBundle::flash.html.twig", "@FOSUser/Security/login.html.twig", 3);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_098be161a6ff02c0160135c258fd4e92fa731f7b74209190dfd0ae2827e8d4c6->leave($__internal_098be161a6ff02c0160135c258fd4e92fa731f7b74209190dfd0ae2827e8d4c6_prof);

        
        $__internal_0b9a7594e572cdef9b034d6c4b282b447019b495eac770c90e2bf6147c0be882->leave($__internal_0b9a7594e572cdef9b034d6c4b282b447019b495eac770c90e2bf6147c0be882_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_6610467b73267073c0c7ee8c9a489d964a58d1a3ab42fe937221625c61e37d52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6610467b73267073c0c7ee8c9a489d964a58d1a3ab42fe937221625c61e37d52->enter($__internal_6610467b73267073c0c7ee8c9a489d964a58d1a3ab42fe937221625c61e37d52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_39834076cb2ded0f5bc8b78cfcdd062edb644fde111cd5d352200aae7cd550a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39834076cb2ded0f5bc8b78cfcdd062edb644fde111cd5d352200aae7cd550a0->enter($__internal_39834076cb2ded0f5bc8b78cfcdd062edb644fde111cd5d352200aae7cd550a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Login";
        
        $__internal_39834076cb2ded0f5bc8b78cfcdd062edb644fde111cd5d352200aae7cd550a0->leave($__internal_39834076cb2ded0f5bc8b78cfcdd062edb644fde111cd5d352200aae7cd550a0_prof);

        
        $__internal_6610467b73267073c0c7ee8c9a489d964a58d1a3ab42fe937221625c61e37d52->leave($__internal_6610467b73267073c0c7ee8c9a489d964a58d1a3ab42fe937221625c61e37d52_prof);

    }

    // line 6
    public function block_headline($context, array $blocks = array())
    {
        $__internal_cad92c5f9b7bb9faf29579e452903d3e00a2d3694fe1457ad6fe62cf9fd1597d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cad92c5f9b7bb9faf29579e452903d3e00a2d3694fe1457ad6fe62cf9fd1597d->enter($__internal_cad92c5f9b7bb9faf29579e452903d3e00a2d3694fe1457ad6fe62cf9fd1597d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        $__internal_c508ad7455e3c25cae175cf5a3e63cfa93b21de56cd663becf99f9ec03d4c422 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c508ad7455e3c25cae175cf5a3e63cfa93b21de56cd663becf99f9ec03d4c422->enter($__internal_c508ad7455e3c25cae175cf5a3e63cfa93b21de56cd663becf99f9ec03d4c422_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        echo "Login";
        
        $__internal_c508ad7455e3c25cae175cf5a3e63cfa93b21de56cd663becf99f9ec03d4c422->leave($__internal_c508ad7455e3c25cae175cf5a3e63cfa93b21de56cd663becf99f9ec03d4c422_prof);

        
        $__internal_cad92c5f9b7bb9faf29579e452903d3e00a2d3694fe1457ad6fe62cf9fd1597d->leave($__internal_cad92c5f9b7bb9faf29579e452903d3e00a2d3694fe1457ad6fe62cf9fd1597d_prof);

    }

    // line 8
    public function block_content_row($context, array $blocks = array())
    {
        $__internal_5d71c422777ea2c4dd713334b13b31fba1e1a5685e1cfee5fb7a668e88fc0dde = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d71c422777ea2c4dd713334b13b31fba1e1a5685e1cfee5fb7a668e88fc0dde->enter($__internal_5d71c422777ea2c4dd713334b13b31fba1e1a5685e1cfee5fb7a668e88fc0dde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        $__internal_aadabe4e330fc09c7a455a89645c537eecb6d823f30281ec0a1b91ce6df8abab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aadabe4e330fc09c7a455a89645c537eecb6d823f30281ec0a1b91ce6df8abab->enter($__internal_aadabe4e330fc09c7a455a89645c537eecb6d823f30281ec0a1b91ce6df8abab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        // line 9
        echo "
    ";
        // line 10
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 11
            echo "        ";
            echo $context["__internal_676875d968d0b32f09406800934c8c97cbfc97aaadb628cd7ac61fe0b8494a03"]->getflash("danger", $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"));
            echo "
    ";
        }
        // line 13
        echo "
    <div class=\"row\">
        <div class=\"col-sm-3\">

            <form action=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
                ";
        // line 18
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 19
            echo "                    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
                ";
        }
        // line 21
        echo "
                <div class=\"form-group\">
                    <label for=\"login-email\">";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.username_or_mail", array(), "messages"), "html", null, true);
        echo "</label>
                    <input type=\"text\" name=\"_username\" class=\"form-control\" id=\"login-email\" placeholder=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.username_or_mail", array(), "messages"), "html", null, true);
        echo "\" value=\"";
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\">
                </div>
                <div class=\"form-group\">
                    <label for=\"login-password\">";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.password", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                    <input type=\"password\" class=\"form-control\" id=\"login-password\" placeholder=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.password", array(), "FOSUserBundle"), "html", null, true);
        echo "\" name=\"_password\" required=\"required\">
                </div>
                <div class=\"checkbox\">
                    <label>
                        <input id=\"remember_me\" name=\"_remember_me\" value=\"on\" type=\"checkbox\">&nbsp;";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.remember_me", array(), "FOSUserBundle"), "html", null, true);
        echo "
                    </label>
                </div>
                <button type=\"submit\" id=\"_submit\" name=\"_submit\" class=\"btn btn-primary\">";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "</button>
            </form>

        </div>
    </div>

";
        
        $__internal_aadabe4e330fc09c7a455a89645c537eecb6d823f30281ec0a1b91ce6df8abab->leave($__internal_aadabe4e330fc09c7a455a89645c537eecb6d823f30281ec0a1b91ce6df8abab_prof);

        
        $__internal_5d71c422777ea2c4dd713334b13b31fba1e1a5685e1cfee5fb7a668e88fc0dde->leave($__internal_5d71c422777ea2c4dd713334b13b31fba1e1a5685e1cfee5fb7a668e88fc0dde_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 35,  146 => 32,  139 => 28,  135 => 27,  127 => 24,  123 => 23,  119 => 21,  113 => 19,  111 => 18,  107 => 17,  101 => 13,  95 => 11,  93 => 10,  90 => 9,  81 => 8,  63 => 6,  45 => 5,  35 => 1,  33 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% trans_default_domain 'FOSUserBundle' %}
{% from 'MopaBootstrapBundle::flash.html.twig' import flash %}

{% block title %}Login{% endblock %}
{% block headline %}Login{% endblock headline %}

{% block content_row %}

    {% if error %}
        {{ flash('danger', error.messageKey|trans(error.messageData, 'security')) }}
    {% endif %}

    <div class=\"row\">
        <div class=\"col-sm-3\">

            <form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
                {% if csrf_token %}
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
                {% endif %}

                <div class=\"form-group\">
                    <label for=\"login-email\">{{ 'security.login.username_or_mail'|trans({}, 'messages') }}</label>
                    <input type=\"text\" name=\"_username\" class=\"form-control\" id=\"login-email\" placeholder=\"{{ 'security.login.username_or_mail'|trans({}, 'messages') }}\" value=\"{{ last_username }}\" required=\"required\">
                </div>
                <div class=\"form-group\">
                    <label for=\"login-password\">{{ 'security.login.password'|trans }}</label>
                    <input type=\"password\" class=\"form-control\" id=\"login-password\" placeholder=\"{{ 'security.login.password'|trans }}\" name=\"_password\" required=\"required\">
                </div>
                <div class=\"checkbox\">
                    <label>
                        <input id=\"remember_me\" name=\"_remember_me\" value=\"on\" type=\"checkbox\">&nbsp;{{ 'security.login.remember_me'|trans }}
                    </label>
                </div>
                <button type=\"submit\" id=\"_submit\" name=\"_submit\" class=\"btn btn-primary\">{{ 'security.login.submit'|trans }}</button>
            </form>

        </div>
    </div>

{% endblock content_row %}
", "@FOSUser/Security/login.html.twig", "/home/henne/Desktop/Project/opium/app/Resources/FOSUserBundle/views/Security/login.html.twig");
    }
}
