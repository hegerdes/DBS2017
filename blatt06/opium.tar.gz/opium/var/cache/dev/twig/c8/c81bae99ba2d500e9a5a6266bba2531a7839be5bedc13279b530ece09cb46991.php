<?php

/* base.html.twig */
class __TwigTemplate_35d7b5ab056a00578908faebe81de4cbccee2b8b72c17c634965d687f195c9dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MopaBootstrapBundle::base.html.twig", "base.html.twig", 1);
        $this->blocks = array(
            'head_style' => array($this, 'block_head_style'),
            'navbar' => array($this, 'block_navbar'),
            'title' => array($this, 'block_title'),
            'headline' => array($this, 'block_headline'),
            'content_row' => array($this, 'block_content_row'),
            'footer' => array($this, 'block_footer'),
            'foot_script_assetic' => array($this, 'block_foot_script_assetic'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MopaBootstrapBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04bf1fd8a2f11bf0e03e3ad0728c9d9fb987c9871357d3b4bb2efb7ea8b3364e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04bf1fd8a2f11bf0e03e3ad0728c9d9fb987c9871357d3b4bb2efb7ea8b3364e->enter($__internal_04bf1fd8a2f11bf0e03e3ad0728c9d9fb987c9871357d3b4bb2efb7ea8b3364e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_60a134e8c1e2345e52f8c87d77d3329de0353068595334db2a6a72dbd085793a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60a134e8c1e2345e52f8c87d77d3329de0353068595334db2a6a72dbd085793a->enter($__internal_60a134e8c1e2345e52f8c87d77d3329de0353068595334db2a6a72dbd085793a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_04bf1fd8a2f11bf0e03e3ad0728c9d9fb987c9871357d3b4bb2efb7ea8b3364e->leave($__internal_04bf1fd8a2f11bf0e03e3ad0728c9d9fb987c9871357d3b4bb2efb7ea8b3364e_prof);

        
        $__internal_60a134e8c1e2345e52f8c87d77d3329de0353068595334db2a6a72dbd085793a->leave($__internal_60a134e8c1e2345e52f8c87d77d3329de0353068595334db2a6a72dbd085793a_prof);

    }

    // line 3
    public function block_head_style($context, array $blocks = array())
    {
        $__internal_45a68448048abcf9e62348d368e1bc1cd1c5ad58def00180539d6d9a33cb3357 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_45a68448048abcf9e62348d368e1bc1cd1c5ad58def00180539d6d9a33cb3357->enter($__internal_45a68448048abcf9e62348d368e1bc1cd1c5ad58def00180539d6d9a33cb3357_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_style"));

        $__internal_ad292faf6a76cc703c3547ebca969e57247d9a10183d0652feab1dacc82d5e77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad292faf6a76cc703c3547ebca969e57247d9a10183d0652feab1dacc82d5e77->enter($__internal_ad292faf6a76cc703c3547ebca969e57247d9a10183d0652feab1dacc82d5e77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_style"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
          integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/base.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_ad292faf6a76cc703c3547ebca969e57247d9a10183d0652feab1dacc82d5e77->leave($__internal_ad292faf6a76cc703c3547ebca969e57247d9a10183d0652feab1dacc82d5e77_prof);

        
        $__internal_45a68448048abcf9e62348d368e1bc1cd1c5ad58def00180539d6d9a33cb3357->leave($__internal_45a68448048abcf9e62348d368e1bc1cd1c5ad58def00180539d6d9a33cb3357_prof);

    }

    // line 9
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_575922cdb9ef978a173c9081d539420126035566599c8568317b76f18d75010f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_575922cdb9ef978a173c9081d539420126035566599c8568317b76f18d75010f->enter($__internal_575922cdb9ef978a173c9081d539420126035566599c8568317b76f18d75010f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_203d100560628258265a46a0df78deef53fe254c140bee0916190d1efae7a20d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_203d100560628258265a46a0df78deef53fe254c140bee0916190d1efae7a20d->enter($__internal_203d100560628258265a46a0df78deef53fe254c140bee0916190d1efae7a20d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        // line 10
        echo "    ";
        $this->loadTemplate("base.html.twig", "base.html.twig", 10, "2120658051")->display(array_merge($context, array("inverse" => true, "id" => "navbar")));
        
        $__internal_203d100560628258265a46a0df78deef53fe254c140bee0916190d1efae7a20d->leave($__internal_203d100560628258265a46a0df78deef53fe254c140bee0916190d1efae7a20d_prof);

        
        $__internal_575922cdb9ef978a173c9081d539420126035566599c8568317b76f18d75010f->leave($__internal_575922cdb9ef978a173c9081d539420126035566599c8568317b76f18d75010f_prof);

    }

    // line 31
    public function block_title($context, array $blocks = array())
    {
        $__internal_8c96ce1c43dddeb9a20e35e2dc224b563ddb5670d0b1489b3c3b3c26b2943039 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c96ce1c43dddeb9a20e35e2dc224b563ddb5670d0b1489b3c3b3c26b2943039->enter($__internal_8c96ce1c43dddeb9a20e35e2dc224b563ddb5670d0b1489b3c3b3c26b2943039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6e131c34a4983acaa211e63c5af1d87ca5d05ab91ebd278fd59d057d09877887 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e131c34a4983acaa211e63c5af1d87ca5d05ab91ebd278fd59d057d09877887->enter($__internal_6e131c34a4983acaa211e63c5af1d87ca5d05ab91ebd278fd59d057d09877887_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_6e131c34a4983acaa211e63c5af1d87ca5d05ab91ebd278fd59d057d09877887->leave($__internal_6e131c34a4983acaa211e63c5af1d87ca5d05ab91ebd278fd59d057d09877887_prof);

        
        $__internal_8c96ce1c43dddeb9a20e35e2dc224b563ddb5670d0b1489b3c3b3c26b2943039->leave($__internal_8c96ce1c43dddeb9a20e35e2dc224b563ddb5670d0b1489b3c3b3c26b2943039_prof);

    }

    // line 32
    public function block_headline($context, array $blocks = array())
    {
        $__internal_065fac8e4b6bfd87594c76e41cb986941ac80de50d3a6eba4ae3d825461f2a12 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_065fac8e4b6bfd87594c76e41cb986941ac80de50d3a6eba4ae3d825461f2a12->enter($__internal_065fac8e4b6bfd87594c76e41cb986941ac80de50d3a6eba4ae3d825461f2a12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        $__internal_ee2887d1ac82cd504e89660cb2c8067012d5844376540f9ec0e35ab4900020ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee2887d1ac82cd504e89660cb2c8067012d5844376540f9ec0e35ab4900020ba->enter($__internal_ee2887d1ac82cd504e89660cb2c8067012d5844376540f9ec0e35ab4900020ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        
        $__internal_ee2887d1ac82cd504e89660cb2c8067012d5844376540f9ec0e35ab4900020ba->leave($__internal_ee2887d1ac82cd504e89660cb2c8067012d5844376540f9ec0e35ab4900020ba_prof);

        
        $__internal_065fac8e4b6bfd87594c76e41cb986941ac80de50d3a6eba4ae3d825461f2a12->leave($__internal_065fac8e4b6bfd87594c76e41cb986941ac80de50d3a6eba4ae3d825461f2a12_prof);

    }

    // line 33
    public function block_content_row($context, array $blocks = array())
    {
        $__internal_a9490377336db9da5971da1cac024d5c831590ed045731b31e076a992c70d668 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9490377336db9da5971da1cac024d5c831590ed045731b31e076a992c70d668->enter($__internal_a9490377336db9da5971da1cac024d5c831590ed045731b31e076a992c70d668_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        $__internal_fa1114f315a09fa84e7440fd5018b61d1be92d29629e2133adc460a0cea96e8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa1114f315a09fa84e7440fd5018b61d1be92d29629e2133adc460a0cea96e8e->enter($__internal_fa1114f315a09fa84e7440fd5018b61d1be92d29629e2133adc460a0cea96e8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        
        $__internal_fa1114f315a09fa84e7440fd5018b61d1be92d29629e2133adc460a0cea96e8e->leave($__internal_fa1114f315a09fa84e7440fd5018b61d1be92d29629e2133adc460a0cea96e8e_prof);

        
        $__internal_a9490377336db9da5971da1cac024d5c831590ed045731b31e076a992c70d668->leave($__internal_a9490377336db9da5971da1cac024d5c831590ed045731b31e076a992c70d668_prof);

    }

    // line 34
    public function block_footer($context, array $blocks = array())
    {
        $__internal_12f6e83f7e8da9dd1c94bf5f1e0fef7e06106db26866f062eb9f2b98f3bc939a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12f6e83f7e8da9dd1c94bf5f1e0fef7e06106db26866f062eb9f2b98f3bc939a->enter($__internal_12f6e83f7e8da9dd1c94bf5f1e0fef7e06106db26866f062eb9f2b98f3bc939a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_bbffec2ab1a4c6b15b2ad64399671b49aafe8b50ceb5f5007a75b5f24062dc7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bbffec2ab1a4c6b15b2ad64399671b49aafe8b50ceb5f5007a75b5f24062dc7a->enter($__internal_bbffec2ab1a4c6b15b2ad64399671b49aafe8b50ceb5f5007a75b5f24062dc7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_bbffec2ab1a4c6b15b2ad64399671b49aafe8b50ceb5f5007a75b5f24062dc7a->leave($__internal_bbffec2ab1a4c6b15b2ad64399671b49aafe8b50ceb5f5007a75b5f24062dc7a_prof);

        
        $__internal_12f6e83f7e8da9dd1c94bf5f1e0fef7e06106db26866f062eb9f2b98f3bc939a->leave($__internal_12f6e83f7e8da9dd1c94bf5f1e0fef7e06106db26866f062eb9f2b98f3bc939a_prof);

    }

    // line 36
    public function block_foot_script_assetic($context, array $blocks = array())
    {
        $__internal_135f57e8c354b1f1cadce696963e880cf698f9a74160a256bcd84b0f83215485 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_135f57e8c354b1f1cadce696963e880cf698f9a74160a256bcd84b0f83215485->enter($__internal_135f57e8c354b1f1cadce696963e880cf698f9a74160a256bcd84b0f83215485_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot_script_assetic"));

        $__internal_9eceffef865f0400f78621ae944e0269003171896dd7c5ea7a33284e0136cedc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9eceffef865f0400f78621ae944e0269003171896dd7c5ea7a33284e0136cedc->enter($__internal_9eceffef865f0400f78621ae944e0269003171896dd7c5ea7a33284e0136cedc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "foot_script_assetic"));

        // line 37
        echo "    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"
            integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\"
            crossorigin=\"anonymous\"></script>
";
        
        $__internal_9eceffef865f0400f78621ae944e0269003171896dd7c5ea7a33284e0136cedc->leave($__internal_9eceffef865f0400f78621ae944e0269003171896dd7c5ea7a33284e0136cedc_prof);

        
        $__internal_135f57e8c354b1f1cadce696963e880cf698f9a74160a256bcd84b0f83215485->leave($__internal_135f57e8c354b1f1cadce696963e880cf698f9a74160a256bcd84b0f83215485_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 37,  159 => 36,  142 => 34,  125 => 33,  108 => 32,  91 => 31,  80 => 10,  71 => 9,  59 => 6,  55 => 4,  46 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'MopaBootstrapBundle::base.html.twig' %}

{% block head_style %}
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
          integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
    <link rel=\"stylesheet\" href=\"{{ asset('css/base.css') }}\" />
{% endblock head_style %}

{% block navbar %}
    {% embed '@MopaBootstrap/Navbar/navbar.html.twig' with { inverse: true, id: 'navbar' } %}
        {% block brand %}
            <a class=\"navbar-brand\" href=\"{{ path('index') }}\">OPIuM</a>
        {% endblock %}

        {% block menu %}
            {% if is_granted(\"ROLE_USER\") %}
                {{ mopa_bootstrap_menu('OpiumBundle:Builder:mainMenu') }}

                {% if is_granted(\"ROLE_ADMIN\") %}
                    {{ mopa_bootstrap_menu('OpiumBundle:Builder:examinerMenu') }}
                {% endif %}

                {{ mopa_bootstrap_menu('OpiumBundle:Builder:userMenu', {'automenu': 'navbar', 'pull-right': true}) }}
            {% else %}
                {{ mopa_bootstrap_menu('OpiumBundle:Builder:loginMenu', {'automenu': 'navbar', 'pull-right': true}) }}
            {% endif %}
        {% endblock %}
    {% endembed %}
{% endblock navbar %}

{% block title %}{% endblock %}
{% block headline %}{% endblock headline %}
{% block content_row %}{% endblock content_row %}
{% block footer %}{% endblock footer %}

{% block foot_script_assetic %}
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"
            integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\"
            crossorigin=\"anonymous\"></script>
{% endblock foot_script_assetic %}
", "base.html.twig", "/home/henne/Desktop/Project/opium/app/Resources/views/base.html.twig");
    }
}


/* base.html.twig */
class __TwigTemplate_35d7b5ab056a00578908faebe81de4cbccee2b8b72c17c634965d687f195c9dc_2120658051 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 10
        $this->parent = $this->loadTemplate("@MopaBootstrap/Navbar/navbar.html.twig", "base.html.twig", 10);
        $this->blocks = array(
            'brand' => array($this, 'block_brand'),
            'menu' => array($this, 'block_menu'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@MopaBootstrap/Navbar/navbar.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6b165c8c13124e78a35a6299b56b40bcb3c6fff77778efb9e82b77b403938bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6b165c8c13124e78a35a6299b56b40bcb3c6fff77778efb9e82b77b403938bb->enter($__internal_f6b165c8c13124e78a35a6299b56b40bcb3c6fff77778efb9e82b77b403938bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_5ebcc4942e9ec47dce18c13dca28eaf99cdc52819b94dbf8a89de3b16733b83c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ebcc4942e9ec47dce18c13dca28eaf99cdc52819b94dbf8a89de3b16733b83c->enter($__internal_5ebcc4942e9ec47dce18c13dca28eaf99cdc52819b94dbf8a89de3b16733b83c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f6b165c8c13124e78a35a6299b56b40bcb3c6fff77778efb9e82b77b403938bb->leave($__internal_f6b165c8c13124e78a35a6299b56b40bcb3c6fff77778efb9e82b77b403938bb_prof);

        
        $__internal_5ebcc4942e9ec47dce18c13dca28eaf99cdc52819b94dbf8a89de3b16733b83c->leave($__internal_5ebcc4942e9ec47dce18c13dca28eaf99cdc52819b94dbf8a89de3b16733b83c_prof);

    }

    // line 11
    public function block_brand($context, array $blocks = array())
    {
        $__internal_b13b65db66abc220220970749c9671e4c5bfb4f194c3c742b0a1d34cefc5e771 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b13b65db66abc220220970749c9671e4c5bfb4f194c3c742b0a1d34cefc5e771->enter($__internal_b13b65db66abc220220970749c9671e4c5bfb4f194c3c742b0a1d34cefc5e771_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "brand"));

        $__internal_017a67aed61b63a77ff5eeb72d8f708ef2c6330178afaa84bebc4a6f1868f661 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_017a67aed61b63a77ff5eeb72d8f708ef2c6330178afaa84bebc4a6f1868f661->enter($__internal_017a67aed61b63a77ff5eeb72d8f708ef2c6330178afaa84bebc4a6f1868f661_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "brand"));

        // line 12
        echo "            <a class=\"navbar-brand\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\">OPIuM</a>
        ";
        
        $__internal_017a67aed61b63a77ff5eeb72d8f708ef2c6330178afaa84bebc4a6f1868f661->leave($__internal_017a67aed61b63a77ff5eeb72d8f708ef2c6330178afaa84bebc4a6f1868f661_prof);

        
        $__internal_b13b65db66abc220220970749c9671e4c5bfb4f194c3c742b0a1d34cefc5e771->leave($__internal_b13b65db66abc220220970749c9671e4c5bfb4f194c3c742b0a1d34cefc5e771_prof);

    }

    // line 15
    public function block_menu($context, array $blocks = array())
    {
        $__internal_34214b64d701ef5219b9489bce20fc9483c9baa874d34d45e91a74bcee607b46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34214b64d701ef5219b9489bce20fc9483c9baa874d34d45e91a74bcee607b46->enter($__internal_34214b64d701ef5219b9489bce20fc9483c9baa874d34d45e91a74bcee607b46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0f0163828e45be91db2a5b88e3284284876d74e3bc6d3357e10b07b360f37dd4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f0163828e45be91db2a5b88e3284284876d74e3bc6d3357e10b07b360f37dd4->enter($__internal_0f0163828e45be91db2a5b88e3284284876d74e3bc6d3357e10b07b360f37dd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 16
        echo "            ";
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 17
            echo "                ";
            echo $this->env->getExtension('Mopa\Bundle\BootstrapBundle\Twig\MenuExtension')->renderMenu("OpiumBundle:Builder:mainMenu");
            echo "

                ";
            // line 19
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                // line 20
                echo "                    ";
                echo $this->env->getExtension('Mopa\Bundle\BootstrapBundle\Twig\MenuExtension')->renderMenu("OpiumBundle:Builder:examinerMenu");
                echo "
                ";
            }
            // line 22
            echo "
                ";
            // line 23
            echo $this->env->getExtension('Mopa\Bundle\BootstrapBundle\Twig\MenuExtension')->renderMenu("OpiumBundle:Builder:userMenu", array("automenu" => "navbar", "pull-right" => true));
            echo "
            ";
        } else {
            // line 25
            echo "                ";
            echo $this->env->getExtension('Mopa\Bundle\BootstrapBundle\Twig\MenuExtension')->renderMenu("OpiumBundle:Builder:loginMenu", array("automenu" => "navbar", "pull-right" => true));
            echo "
            ";
        }
        // line 27
        echo "        ";
        
        $__internal_0f0163828e45be91db2a5b88e3284284876d74e3bc6d3357e10b07b360f37dd4->leave($__internal_0f0163828e45be91db2a5b88e3284284876d74e3bc6d3357e10b07b360f37dd4_prof);

        
        $__internal_34214b64d701ef5219b9489bce20fc9483c9baa874d34d45e91a74bcee607b46->leave($__internal_34214b64d701ef5219b9489bce20fc9483c9baa874d34d45e91a74bcee607b46_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  352 => 27,  346 => 25,  341 => 23,  338 => 22,  332 => 20,  330 => 19,  324 => 17,  321 => 16,  312 => 15,  299 => 12,  290 => 11,  260 => 10,  168 => 37,  159 => 36,  142 => 34,  125 => 33,  108 => 32,  91 => 31,  80 => 10,  71 => 9,  59 => 6,  55 => 4,  46 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'MopaBootstrapBundle::base.html.twig' %}

{% block head_style %}
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"
          integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
    <link rel=\"stylesheet\" href=\"{{ asset('css/base.css') }}\" />
{% endblock head_style %}

{% block navbar %}
    {% embed '@MopaBootstrap/Navbar/navbar.html.twig' with { inverse: true, id: 'navbar' } %}
        {% block brand %}
            <a class=\"navbar-brand\" href=\"{{ path('index') }}\">OPIuM</a>
        {% endblock %}

        {% block menu %}
            {% if is_granted(\"ROLE_USER\") %}
                {{ mopa_bootstrap_menu('OpiumBundle:Builder:mainMenu') }}

                {% if is_granted(\"ROLE_ADMIN\") %}
                    {{ mopa_bootstrap_menu('OpiumBundle:Builder:examinerMenu') }}
                {% endif %}

                {{ mopa_bootstrap_menu('OpiumBundle:Builder:userMenu', {'automenu': 'navbar', 'pull-right': true}) }}
            {% else %}
                {{ mopa_bootstrap_menu('OpiumBundle:Builder:loginMenu', {'automenu': 'navbar', 'pull-right': true}) }}
            {% endif %}
        {% endblock %}
    {% endembed %}
{% endblock navbar %}

{% block title %}{% endblock %}
{% block headline %}{% endblock headline %}
{% block content_row %}{% endblock content_row %}
{% block footer %}{% endblock footer %}

{% block foot_script_assetic %}
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"
            integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\"
            crossorigin=\"anonymous\"></script>
{% endblock foot_script_assetic %}
", "base.html.twig", "/home/henne/Desktop/Project/opium/app/Resources/views/base.html.twig");
    }
}
