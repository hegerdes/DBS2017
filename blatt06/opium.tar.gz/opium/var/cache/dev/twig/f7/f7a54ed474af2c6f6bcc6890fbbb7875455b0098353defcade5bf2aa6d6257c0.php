<?php

/* knp_menu_base.html.twig */
class __TwigTemplate_fb6310d89326e58029f84d146b9ccfc233d4ffbc1ad074ffcdb7b775b85c1ac8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d4c202dddd0cfdf450d9c1d36cc683550cf80177b7783c7b746379cc8c9ffc6c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4c202dddd0cfdf450d9c1d36cc683550cf80177b7783c7b746379cc8c9ffc6c->enter($__internal_d4c202dddd0cfdf450d9c1d36cc683550cf80177b7783c7b746379cc8c9ffc6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_base.html.twig"));

        $__internal_ff2c931099fbb603ef29c3db2530e2b95d0435a21eb6600d119ec9db886c43a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff2c931099fbb603ef29c3db2530e2b95d0435a21eb6600d119ec9db886c43a9->enter($__internal_ff2c931099fbb603ef29c3db2530e2b95d0435a21eb6600d119ec9db886c43a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_base.html.twig"));

        // line 1
        if ($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "compressed", array())) {
            $this->displayBlock("compressed_root", $context, $blocks);
        } else {
            $this->displayBlock("root", $context, $blocks);
        }
        
        $__internal_d4c202dddd0cfdf450d9c1d36cc683550cf80177b7783c7b746379cc8c9ffc6c->leave($__internal_d4c202dddd0cfdf450d9c1d36cc683550cf80177b7783c7b746379cc8c9ffc6c_prof);

        
        $__internal_ff2c931099fbb603ef29c3db2530e2b95d0435a21eb6600d119ec9db886c43a9->leave($__internal_ff2c931099fbb603ef29c3db2530e2b95d0435a21eb6600d119ec9db886c43a9_prof);

    }

    public function getTemplateName()
    {
        return "knp_menu_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if options.compressed %}{{ block('compressed_root') }}{% else %}{{ block('root') }}{% endif %}
", "knp_menu_base.html.twig", "/home/henne/Desktop/Project/opium/vendor/knplabs/knp-menu/src/Knp/Menu/Resources/views/knp_menu_base.html.twig");
    }
}
