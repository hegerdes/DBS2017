<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_734b9de5f2ec6b5b89ff9e91d43449e1d00303c0f07bf2cdfeca14a6e54798b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c52624f5c43e19ca2d30e08288f272df324a489749c676ae7fe94bde74ee707c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c52624f5c43e19ca2d30e08288f272df324a489749c676ae7fe94bde74ee707c->enter($__internal_c52624f5c43e19ca2d30e08288f272df324a489749c676ae7fe94bde74ee707c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_43aef6dfd923e1cb806559b24d80ea49cc1ba3663b9dbadc7b086478d38e377c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43aef6dfd923e1cb806559b24d80ea49cc1ba3663b9dbadc7b086478d38e377c->enter($__internal_43aef6dfd923e1cb806559b24d80ea49cc1ba3663b9dbadc7b086478d38e377c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c52624f5c43e19ca2d30e08288f272df324a489749c676ae7fe94bde74ee707c->leave($__internal_c52624f5c43e19ca2d30e08288f272df324a489749c676ae7fe94bde74ee707c_prof);

        
        $__internal_43aef6dfd923e1cb806559b24d80ea49cc1ba3663b9dbadc7b086478d38e377c->leave($__internal_43aef6dfd923e1cb806559b24d80ea49cc1ba3663b9dbadc7b086478d38e377c_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_1bcf692da76fdfe3e8b4f69f391b3fb9f35a1488ab6cc980031ea927e25bfd16 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1bcf692da76fdfe3e8b4f69f391b3fb9f35a1488ab6cc980031ea927e25bfd16->enter($__internal_1bcf692da76fdfe3e8b4f69f391b3fb9f35a1488ab6cc980031ea927e25bfd16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_0ac4843b74a4ce84d8c5240730efa2481832754f1bc4fbfb03a68163f27a3e83 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ac4843b74a4ce84d8c5240730efa2481832754f1bc4fbfb03a68163f27a3e83->enter($__internal_0ac4843b74a4ce84d8c5240730efa2481832754f1bc4fbfb03a68163f27a3e83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_0ac4843b74a4ce84d8c5240730efa2481832754f1bc4fbfb03a68163f27a3e83->leave($__internal_0ac4843b74a4ce84d8c5240730efa2481832754f1bc4fbfb03a68163f27a3e83_prof);

        
        $__internal_1bcf692da76fdfe3e8b4f69f391b3fb9f35a1488ab6cc980031ea927e25bfd16->leave($__internal_1bcf692da76fdfe3e8b4f69f391b3fb9f35a1488ab6cc980031ea927e25bfd16_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b5a79a79ff329c3b3ed75e332106e9ef1a6c46b28b397f075e1c01d874cece8d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b5a79a79ff329c3b3ed75e332106e9ef1a6c46b28b397f075e1c01d874cece8d->enter($__internal_b5a79a79ff329c3b3ed75e332106e9ef1a6c46b28b397f075e1c01d874cece8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ac6e994f8e13286c78bb5ded1efaf6b532fd637d15421d99cdeb3d5eaab5c0cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac6e994f8e13286c78bb5ded1efaf6b532fd637d15421d99cdeb3d5eaab5c0cf->enter($__internal_ac6e994f8e13286c78bb5ded1efaf6b532fd637d15421d99cdeb3d5eaab5c0cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_ac6e994f8e13286c78bb5ded1efaf6b532fd637d15421d99cdeb3d5eaab5c0cf->leave($__internal_ac6e994f8e13286c78bb5ded1efaf6b532fd637d15421d99cdeb3d5eaab5c0cf_prof);

        
        $__internal_b5a79a79ff329c3b3ed75e332106e9ef1a6c46b28b397f075e1c01d874cece8d->leave($__internal_b5a79a79ff329c3b3ed75e332106e9ef1a6c46b28b397f075e1c01d874cece8d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2b9d3a93687dd4cc36c0640ef6d8528ba09b43afaa829b678252bd85fd51fe28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b9d3a93687dd4cc36c0640ef6d8528ba09b43afaa829b678252bd85fd51fe28->enter($__internal_2b9d3a93687dd4cc36c0640ef6d8528ba09b43afaa829b678252bd85fd51fe28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_e7946e60621f18c87316b1a2d4d906b0dcf27be5224386d24368e10d83f14424 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7946e60621f18c87316b1a2d4d906b0dcf27be5224386d24368e10d83f14424->enter($__internal_e7946e60621f18c87316b1a2d4d906b0dcf27be5224386d24368e10d83f14424_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e7946e60621f18c87316b1a2d4d906b0dcf27be5224386d24368e10d83f14424->leave($__internal_e7946e60621f18c87316b1a2d4d906b0dcf27be5224386d24368e10d83f14424_prof);

        
        $__internal_2b9d3a93687dd4cc36c0640ef6d8528ba09b43afaa829b678252bd85fd51fe28->leave($__internal_2b9d3a93687dd4cc36c0640ef6d8528ba09b43afaa829b678252bd85fd51fe28_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/henne/Desktop/Project/opium/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
