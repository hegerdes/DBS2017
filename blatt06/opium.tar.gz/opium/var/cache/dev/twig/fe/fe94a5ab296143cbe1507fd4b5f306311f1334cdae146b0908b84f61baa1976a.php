<?php

/* knp_menu.html.twig */
class __TwigTemplate_c3d498848c82da9e3e6d92d72d9f414f6a544d6ebe0e20ea4a817f5895079696 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("knp_menu_base.html.twig", "knp_menu.html.twig", 1);
        $this->blocks = array(
            'compressed_root' => array($this, 'block_compressed_root'),
            'root' => array($this, 'block_root'),
            'list' => array($this, 'block_list'),
            'children' => array($this, 'block_children'),
            'item' => array($this, 'block_item'),
            'linkElement' => array($this, 'block_linkElement'),
            'spanElement' => array($this, 'block_spanElement'),
            'label' => array($this, 'block_label'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "knp_menu_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d66acb93021def34b49ebf2561264e67fbc1948195746df8536e38bae2a5f78 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d66acb93021def34b49ebf2561264e67fbc1948195746df8536e38bae2a5f78->enter($__internal_3d66acb93021def34b49ebf2561264e67fbc1948195746df8536e38bae2a5f78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu.html.twig"));

        $__internal_982ccde0dbc04666745741bd0621fd1008d7e7fc49eebcb3d678deae1e4c0029 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_982ccde0dbc04666745741bd0621fd1008d7e7fc49eebcb3d678deae1e4c0029->enter($__internal_982ccde0dbc04666745741bd0621fd1008d7e7fc49eebcb3d678deae1e4c0029_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3d66acb93021def34b49ebf2561264e67fbc1948195746df8536e38bae2a5f78->leave($__internal_3d66acb93021def34b49ebf2561264e67fbc1948195746df8536e38bae2a5f78_prof);

        
        $__internal_982ccde0dbc04666745741bd0621fd1008d7e7fc49eebcb3d678deae1e4c0029->leave($__internal_982ccde0dbc04666745741bd0621fd1008d7e7fc49eebcb3d678deae1e4c0029_prof);

    }

    // line 11
    public function block_compressed_root($context, array $blocks = array())
    {
        $__internal_42a247da53288b886fc34d0fcd716affe3debde0d0a8e678e96be16b36044d61 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42a247da53288b886fc34d0fcd716affe3debde0d0a8e678e96be16b36044d61->enter($__internal_42a247da53288b886fc34d0fcd716affe3debde0d0a8e678e96be16b36044d61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "compressed_root"));

        $__internal_d374a30d990ec3af05d0dd68f51cad80639af1e8791287706ad3b2474546ef00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d374a30d990ec3af05d0dd68f51cad80639af1e8791287706ad3b2474546ef00->enter($__internal_d374a30d990ec3af05d0dd68f51cad80639af1e8791287706ad3b2474546ef00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "compressed_root"));

        // line 12
        ob_start();
        // line 13
        $this->displayBlock("root", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_d374a30d990ec3af05d0dd68f51cad80639af1e8791287706ad3b2474546ef00->leave($__internal_d374a30d990ec3af05d0dd68f51cad80639af1e8791287706ad3b2474546ef00_prof);

        
        $__internal_42a247da53288b886fc34d0fcd716affe3debde0d0a8e678e96be16b36044d61->leave($__internal_42a247da53288b886fc34d0fcd716affe3debde0d0a8e678e96be16b36044d61_prof);

    }

    // line 17
    public function block_root($context, array $blocks = array())
    {
        $__internal_890a5335c744a22aaada4751fe5ba563ac8f5622f2eee9daa69bd001f46c464f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_890a5335c744a22aaada4751fe5ba563ac8f5622f2eee9daa69bd001f46c464f->enter($__internal_890a5335c744a22aaada4751fe5ba563ac8f5622f2eee9daa69bd001f46c464f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "root"));

        $__internal_bb9aec7e0a37ce5b836672abebed97c3ed5babe64c4e54a8c371bbd6b8a6cda1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb9aec7e0a37ce5b836672abebed97c3ed5babe64c4e54a8c371bbd6b8a6cda1->enter($__internal_bb9aec7e0a37ce5b836672abebed97c3ed5babe64c4e54a8c371bbd6b8a6cda1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "root"));

        // line 18
        $context["listAttributes"] = $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "childrenAttributes", array());
        // line 19
        $this->displayBlock("list", $context, $blocks);
        
        $__internal_bb9aec7e0a37ce5b836672abebed97c3ed5babe64c4e54a8c371bbd6b8a6cda1->leave($__internal_bb9aec7e0a37ce5b836672abebed97c3ed5babe64c4e54a8c371bbd6b8a6cda1_prof);

        
        $__internal_890a5335c744a22aaada4751fe5ba563ac8f5622f2eee9daa69bd001f46c464f->leave($__internal_890a5335c744a22aaada4751fe5ba563ac8f5622f2eee9daa69bd001f46c464f_prof);

    }

    // line 22
    public function block_list($context, array $blocks = array())
    {
        $__internal_0caef9ce66d120a4a42c73f820b37d5e646d14a98aa304b18bc5b45dec7dddf4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0caef9ce66d120a4a42c73f820b37d5e646d14a98aa304b18bc5b45dec7dddf4->enter($__internal_0caef9ce66d120a4a42c73f820b37d5e646d14a98aa304b18bc5b45dec7dddf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "list"));

        $__internal_af96ebbd9eda68d6d45c09d3877f493e536c97ff779029ac29430fa4a587bbf4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af96ebbd9eda68d6d45c09d3877f493e536c97ff779029ac29430fa4a587bbf4->enter($__internal_af96ebbd9eda68d6d45c09d3877f493e536c97ff779029ac29430fa4a587bbf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "list"));

        // line 23
        if ((($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "hasChildren", array()) &&  !($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "depth", array()) === 0)) && $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "displayChildren", array()))) {
            // line 24
            echo "    ";
            $context["knp_menu"] = $this;
            // line 25
            echo "    <ul";
            echo $context["knp_menu"]->getattributes(($context["listAttributes"] ?? $this->getContext($context, "listAttributes")));
            echo ">
        ";
            // line 26
            $this->displayBlock("children", $context, $blocks);
            echo "
    </ul>
";
        }
        
        $__internal_af96ebbd9eda68d6d45c09d3877f493e536c97ff779029ac29430fa4a587bbf4->leave($__internal_af96ebbd9eda68d6d45c09d3877f493e536c97ff779029ac29430fa4a587bbf4_prof);

        
        $__internal_0caef9ce66d120a4a42c73f820b37d5e646d14a98aa304b18bc5b45dec7dddf4->leave($__internal_0caef9ce66d120a4a42c73f820b37d5e646d14a98aa304b18bc5b45dec7dddf4_prof);

    }

    // line 31
    public function block_children($context, array $blocks = array())
    {
        $__internal_6f3b20eddb4a7738206bec44bcb1cbdce281b14ee81ffb2b58acbfe67de15d14 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6f3b20eddb4a7738206bec44bcb1cbdce281b14ee81ffb2b58acbfe67de15d14->enter($__internal_6f3b20eddb4a7738206bec44bcb1cbdce281b14ee81ffb2b58acbfe67de15d14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "children"));

        $__internal_531d3200ff1482fedf0f110e2978ba04696a5585279128ba7677c03ca3dd0822 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_531d3200ff1482fedf0f110e2978ba04696a5585279128ba7677c03ca3dd0822->enter($__internal_531d3200ff1482fedf0f110e2978ba04696a5585279128ba7677c03ca3dd0822_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "children"));

        // line 33
        $context["currentOptions"] = ($context["options"] ?? $this->getContext($context, "options"));
        // line 34
        $context["currentItem"] = ($context["item"] ?? $this->getContext($context, "item"));
        // line 36
        if ( !(null === $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "depth", array()))) {
            // line 37
            $context["options"] = twig_array_merge(($context["options"] ?? $this->getContext($context, "options")), array("depth" => ($this->getAttribute(($context["currentOptions"] ?? $this->getContext($context, "currentOptions")), "depth", array()) - 1)));
        }
        // line 40
        if (( !(null === $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "matchingDepth", array())) && ($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "matchingDepth", array()) > 0))) {
            // line 41
            $context["options"] = twig_array_merge(($context["options"] ?? $this->getContext($context, "options")), array("matchingDepth" => ($this->getAttribute(($context["currentOptions"] ?? $this->getContext($context, "currentOptions")), "matchingDepth", array()) - 1)));
        }
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["currentItem"] ?? $this->getContext($context, "currentItem")), "children", array()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 44
            echo "    ";
            $this->displayBlock("item", $context, $blocks);
            echo "
";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        $context["item"] = ($context["currentItem"] ?? $this->getContext($context, "currentItem"));
        // line 48
        $context["options"] = ($context["currentOptions"] ?? $this->getContext($context, "currentOptions"));
        
        $__internal_531d3200ff1482fedf0f110e2978ba04696a5585279128ba7677c03ca3dd0822->leave($__internal_531d3200ff1482fedf0f110e2978ba04696a5585279128ba7677c03ca3dd0822_prof);

        
        $__internal_6f3b20eddb4a7738206bec44bcb1cbdce281b14ee81ffb2b58acbfe67de15d14->leave($__internal_6f3b20eddb4a7738206bec44bcb1cbdce281b14ee81ffb2b58acbfe67de15d14_prof);

    }

    // line 51
    public function block_item($context, array $blocks = array())
    {
        $__internal_70f432c3cec54b5db784d67de45ca41a616c0e59bf819f61b659f89a5fefe0ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70f432c3cec54b5db784d67de45ca41a616c0e59bf819f61b659f89a5fefe0ec->enter($__internal_70f432c3cec54b5db784d67de45ca41a616c0e59bf819f61b659f89a5fefe0ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "item"));

        $__internal_253772c119aad8c25b5b277326704b2d4c2c84a9c49c3cca2ceaa1df27b841ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_253772c119aad8c25b5b277326704b2d4c2c84a9c49c3cca2ceaa1df27b841ea->enter($__internal_253772c119aad8c25b5b277326704b2d4c2c84a9c49c3cca2ceaa1df27b841ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "item"));

        // line 52
        if ($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "displayed", array())) {
            // line 54
            $context["classes"] = (( !twig_test_empty($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "attribute", array(0 => "class"), "method"))) ? (array(0 => $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "attribute", array(0 => "class"), "method"))) : (array()));
            // line 55
            if ($this->getAttribute(($context["matcher"] ?? $this->getContext($context, "matcher")), "isCurrent", array(0 => ($context["item"] ?? $this->getContext($context, "item"))), "method")) {
                // line 56
                $context["classes"] = twig_array_merge(($context["classes"] ?? $this->getContext($context, "classes")), array(0 => $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "currentClass", array())));
            } elseif ($this->getAttribute(            // line 57
($context["matcher"] ?? $this->getContext($context, "matcher")), "isAncestor", array(0 => ($context["item"] ?? $this->getContext($context, "item")), 1 => $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "matchingDepth", array())), "method")) {
                // line 58
                $context["classes"] = twig_array_merge(($context["classes"] ?? $this->getContext($context, "classes")), array(0 => $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "ancestorClass", array())));
            }
            // line 60
            if ($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "actsLikeFirst", array())) {
                // line 61
                $context["classes"] = twig_array_merge(($context["classes"] ?? $this->getContext($context, "classes")), array(0 => $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "firstClass", array())));
            }
            // line 63
            if ($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "actsLikeLast", array())) {
                // line 64
                $context["classes"] = twig_array_merge(($context["classes"] ?? $this->getContext($context, "classes")), array(0 => $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "lastClass", array())));
            }
            // line 66
            echo "
    ";
            // line 68
            echo "    ";
            if (($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "hasChildren", array()) &&  !($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "depth", array()) === 0))) {
                // line 69
                echo "        ";
                if (( !twig_test_empty($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "branch_class", array())) && $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "displayChildren", array()))) {
                    // line 70
                    $context["classes"] = twig_array_merge(($context["classes"] ?? $this->getContext($context, "classes")), array(0 => $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "branch_class", array())));
                    // line 71
                    echo "        ";
                }
                // line 72
                echo "    ";
            } elseif ( !twig_test_empty($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "leaf_class", array()))) {
                // line 73
                $context["classes"] = twig_array_merge(($context["classes"] ?? $this->getContext($context, "classes")), array(0 => $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "leaf_class", array())));
            }
            // line 76
            $context["attributes"] = $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "attributes", array());
            // line 77
            if ( !twig_test_empty(($context["classes"] ?? $this->getContext($context, "classes")))) {
                // line 78
                $context["attributes"] = twig_array_merge(($context["attributes"] ?? $this->getContext($context, "attributes")), array("class" => twig_join_filter(($context["classes"] ?? $this->getContext($context, "classes")), " ")));
            }
            // line 81
            echo "    ";
            $context["knp_menu"] = $this;
            // line 82
            echo "    <li";
            echo $context["knp_menu"]->getattributes(($context["attributes"] ?? $this->getContext($context, "attributes")));
            echo ">";
            // line 83
            if (( !twig_test_empty($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "uri", array())) && ( !$this->getAttribute(($context["matcher"] ?? $this->getContext($context, "matcher")), "isCurrent", array(0 => ($context["item"] ?? $this->getContext($context, "item"))), "method") || $this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "currentAsLink", array())))) {
                // line 84
                echo "        ";
                $this->displayBlock("linkElement", $context, $blocks);
            } else {
                // line 86
                echo "        ";
                $this->displayBlock("spanElement", $context, $blocks);
            }
            // line 89
            $context["childrenClasses"] = (( !twig_test_empty($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "childrenAttribute", array(0 => "class"), "method"))) ? (array(0 => $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "childrenAttribute", array(0 => "class"), "method"))) : (array()));
            // line 90
            $context["childrenClasses"] = twig_array_merge(($context["childrenClasses"] ?? $this->getContext($context, "childrenClasses")), array(0 => ("menu_level_" . $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "level", array()))));
            // line 91
            $context["listAttributes"] = twig_array_merge($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "childrenAttributes", array()), array("class" => twig_join_filter(($context["childrenClasses"] ?? $this->getContext($context, "childrenClasses")), " ")));
            // line 92
            echo "        ";
            $this->displayBlock("list", $context, $blocks);
            echo "
    </li>
";
        }
        
        $__internal_253772c119aad8c25b5b277326704b2d4c2c84a9c49c3cca2ceaa1df27b841ea->leave($__internal_253772c119aad8c25b5b277326704b2d4c2c84a9c49c3cca2ceaa1df27b841ea_prof);

        
        $__internal_70f432c3cec54b5db784d67de45ca41a616c0e59bf819f61b659f89a5fefe0ec->leave($__internal_70f432c3cec54b5db784d67de45ca41a616c0e59bf819f61b659f89a5fefe0ec_prof);

    }

    // line 97
    public function block_linkElement($context, array $blocks = array())
    {
        $__internal_ef28effb477890e9773c8fb3016de7db1aa025b21b5b00d7c601adcf53b839ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ef28effb477890e9773c8fb3016de7db1aa025b21b5b00d7c601adcf53b839ae->enter($__internal_ef28effb477890e9773c8fb3016de7db1aa025b21b5b00d7c601adcf53b839ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "linkElement"));

        $__internal_b9661b0dbb1e32da6def9f7fba62a5dbdd2e559026b6f90467b5a4da5e2a0a5f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9661b0dbb1e32da6def9f7fba62a5dbdd2e559026b6f90467b5a4da5e2a0a5f->enter($__internal_b9661b0dbb1e32da6def9f7fba62a5dbdd2e559026b6f90467b5a4da5e2a0a5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "linkElement"));

        $context["knp_menu"] = $this;
        echo "<a href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "uri", array()), "html", null, true);
        echo "\"";
        echo $context["knp_menu"]->getattributes($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "linkAttributes", array()));
        echo ">";
        $this->displayBlock("label", $context, $blocks);
        echo "</a>";
        
        $__internal_b9661b0dbb1e32da6def9f7fba62a5dbdd2e559026b6f90467b5a4da5e2a0a5f->leave($__internal_b9661b0dbb1e32da6def9f7fba62a5dbdd2e559026b6f90467b5a4da5e2a0a5f_prof);

        
        $__internal_ef28effb477890e9773c8fb3016de7db1aa025b21b5b00d7c601adcf53b839ae->leave($__internal_ef28effb477890e9773c8fb3016de7db1aa025b21b5b00d7c601adcf53b839ae_prof);

    }

    // line 99
    public function block_spanElement($context, array $blocks = array())
    {
        $__internal_c5f429057e62554b982beb9c2d8604e44337f0d92e5fc9af4c328cb62f9e127a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5f429057e62554b982beb9c2d8604e44337f0d92e5fc9af4c328cb62f9e127a->enter($__internal_c5f429057e62554b982beb9c2d8604e44337f0d92e5fc9af4c328cb62f9e127a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "spanElement"));

        $__internal_30e250a8878b9f67a8dbe5ba99e37185165d760e5990ab1e8b281004b1f7d265 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_30e250a8878b9f67a8dbe5ba99e37185165d760e5990ab1e8b281004b1f7d265->enter($__internal_30e250a8878b9f67a8dbe5ba99e37185165d760e5990ab1e8b281004b1f7d265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "spanElement"));

        $context["knp_menu"] = $this;
        echo "<span";
        echo $context["knp_menu"]->getattributes($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "labelAttributes", array()));
        echo ">";
        $this->displayBlock("label", $context, $blocks);
        echo "</span>";
        
        $__internal_30e250a8878b9f67a8dbe5ba99e37185165d760e5990ab1e8b281004b1f7d265->leave($__internal_30e250a8878b9f67a8dbe5ba99e37185165d760e5990ab1e8b281004b1f7d265_prof);

        
        $__internal_c5f429057e62554b982beb9c2d8604e44337f0d92e5fc9af4c328cb62f9e127a->leave($__internal_c5f429057e62554b982beb9c2d8604e44337f0d92e5fc9af4c328cb62f9e127a_prof);

    }

    // line 101
    public function block_label($context, array $blocks = array())
    {
        $__internal_16150a4729fe75c8ad6ad0cc9228c11098f6cfad19a35b014bdb5096ee47d80d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16150a4729fe75c8ad6ad0cc9228c11098f6cfad19a35b014bdb5096ee47d80d->enter($__internal_16150a4729fe75c8ad6ad0cc9228c11098f6cfad19a35b014bdb5096ee47d80d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "label"));

        $__internal_11e953a0c220dd3e6251cf597a314dac6c37e84e8b802804c66319737f585f40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11e953a0c220dd3e6251cf597a314dac6c37e84e8b802804c66319737f585f40->enter($__internal_11e953a0c220dd3e6251cf597a314dac6c37e84e8b802804c66319737f585f40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "label"));

        if (($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "allow_safe_labels", array()) && $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "getExtra", array(0 => "safe_label", 1 => false), "method"))) {
            echo $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "label", array());
        } else {
            echo twig_escape_filter($this->env, $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "label", array()), "html", null, true);
        }
        
        $__internal_11e953a0c220dd3e6251cf597a314dac6c37e84e8b802804c66319737f585f40->leave($__internal_11e953a0c220dd3e6251cf597a314dac6c37e84e8b802804c66319737f585f40_prof);

        
        $__internal_16150a4729fe75c8ad6ad0cc9228c11098f6cfad19a35b014bdb5096ee47d80d->leave($__internal_16150a4729fe75c8ad6ad0cc9228c11098f6cfad19a35b014bdb5096ee47d80d_prof);

    }

    // line 3
    public function getattributes($__attributes__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "attributes" => $__attributes__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_028c13e26600382770910b49b276d923db85e02450fa23d666dc6f8cd310e8ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_028c13e26600382770910b49b276d923db85e02450fa23d666dc6f8cd310e8ff->enter($__internal_028c13e26600382770910b49b276d923db85e02450fa23d666dc6f8cd310e8ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "attributes"));

            $__internal_9b25de3d0f684a550e32eb830526ad61c684dc51f05ad4d737bbc186c80eefbd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_9b25de3d0f684a550e32eb830526ad61c684dc51f05ad4d737bbc186c80eefbd->enter($__internal_9b25de3d0f684a550e32eb830526ad61c684dc51f05ad4d737bbc186c80eefbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "attributes"));

            // line 4
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["attributes"] ?? $this->getContext($context, "attributes")));
            foreach ($context['_seq'] as $context["name"] => $context["value"]) {
                // line 5
                if (( !(null === $context["value"]) &&  !($context["value"] === false))) {
                    // line 6
                    echo sprintf(" %s=\"%s\"", $context["name"], ((($context["value"] === true)) ? (twig_escape_filter($this->env, $context["name"])) : (twig_escape_filter($this->env, $context["value"]))));
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['name'], $context['value'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            
            $__internal_9b25de3d0f684a550e32eb830526ad61c684dc51f05ad4d737bbc186c80eefbd->leave($__internal_9b25de3d0f684a550e32eb830526ad61c684dc51f05ad4d737bbc186c80eefbd_prof);

            
            $__internal_028c13e26600382770910b49b276d923db85e02450fa23d666dc6f8cd310e8ff->leave($__internal_028c13e26600382770910b49b276d923db85e02450fa23d666dc6f8cd310e8ff_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "knp_menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  385 => 6,  383 => 5,  379 => 4,  361 => 3,  339 => 101,  316 => 99,  291 => 97,  276 => 92,  274 => 91,  272 => 90,  270 => 89,  266 => 86,  262 => 84,  260 => 83,  256 => 82,  253 => 81,  250 => 78,  248 => 77,  246 => 76,  243 => 73,  240 => 72,  237 => 71,  235 => 70,  232 => 69,  229 => 68,  226 => 66,  223 => 64,  221 => 63,  218 => 61,  216 => 60,  213 => 58,  211 => 57,  209 => 56,  207 => 55,  205 => 54,  203 => 52,  194 => 51,  184 => 48,  182 => 47,  165 => 44,  148 => 43,  145 => 41,  143 => 40,  140 => 37,  138 => 36,  136 => 34,  134 => 33,  125 => 31,  111 => 26,  106 => 25,  103 => 24,  101 => 23,  92 => 22,  82 => 19,  80 => 18,  71 => 17,  58 => 13,  56 => 12,  47 => 11,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'knp_menu_base.html.twig' %}

{% macro attributes(attributes) %}
{% for name, value in attributes %}
    {%- if value is not none and value is not same as(false) -%}
        {{- ' %s=\"%s\"'|format(name, value is same as(true) ? name|e : value|e)|raw -}}
    {%- endif -%}
{%- endfor -%}
{% endmacro %}

{% block compressed_root %}
{% spaceless %}
{{ block('root') }}
{% endspaceless %}
{% endblock %}

{% block root %}
{% set listAttributes = item.childrenAttributes %}
{{ block('list') -}}
{% endblock %}

{% block list %}
{% if item.hasChildren and options.depth is not same as(0) and item.displayChildren %}
    {% import _self as knp_menu %}
    <ul{{ knp_menu.attributes(listAttributes) }}>
        {{ block('children') }}
    </ul>
{% endif %}
{% endblock %}

{% block children %}
{# save current variables #}
{% set currentOptions = options %}
{% set currentItem = item %}
{# update the depth for children #}
{% if options.depth is not none %}
{% set options = options|merge({'depth': currentOptions.depth - 1}) %}
{% endif %}
{# update the matchingDepth for children #}
{% if options.matchingDepth is not none and options.matchingDepth > 0 %}
{% set options = options|merge({'matchingDepth': currentOptions.matchingDepth - 1}) %}
{% endif %}
{% for item in currentItem.children %}
    {{ block('item') }}
{% endfor %}
{# restore current variables #}
{% set item = currentItem %}
{% set options = currentOptions %}
{% endblock %}

{% block item %}
{% if item.displayed %}
{# building the class of the item #}
    {%- set classes = item.attribute('class') is not empty ? [item.attribute('class')] : [] %}
    {%- if matcher.isCurrent(item) %}
        {%- set classes = classes|merge([options.currentClass]) %}
    {%- elseif matcher.isAncestor(item, options.matchingDepth) %}
        {%- set classes = classes|merge([options.ancestorClass]) %}
    {%- endif %}
    {%- if item.actsLikeFirst %}
        {%- set classes = classes|merge([options.firstClass]) %}
    {%- endif %}
    {%- if item.actsLikeLast %}
        {%- set classes = classes|merge([options.lastClass]) %}
    {%- endif %}

    {# Mark item as \"leaf\" (no children) or as \"branch\" (has children that are displayed) #}
    {% if item.hasChildren and options.depth is not same as(0) %}
        {% if options.branch_class is not empty and item.displayChildren %}
            {%- set classes = classes|merge([options.branch_class]) %}
        {% endif %}
    {% elseif options.leaf_class is not empty %}
        {%- set classes = classes|merge([options.leaf_class]) %}
    {%- endif %}

    {%- set attributes = item.attributes %}
    {%- if classes is not empty %}
        {%- set attributes = attributes|merge({'class': classes|join(' ')}) %}
    {%- endif %}
{# displaying the item #}
    {% import _self as knp_menu %}
    <li{{ knp_menu.attributes(attributes) }}>
        {%- if item.uri is not empty and (not matcher.isCurrent(item) or options.currentAsLink) %}
        {{ block('linkElement') }}
        {%- else %}
        {{ block('spanElement') }}
        {%- endif %}
{# render the list of children#}
        {%- set childrenClasses = item.childrenAttribute('class') is not empty ? [item.childrenAttribute('class')] : [] %}
        {%- set childrenClasses = childrenClasses|merge(['menu_level_' ~ item.level]) %}
        {%- set listAttributes = item.childrenAttributes|merge({'class': childrenClasses|join(' ') }) %}
        {{ block('list') }}
    </li>
{% endif %}
{% endblock %}

{% block linkElement %}{% import _self as knp_menu %}<a href=\"{{ item.uri }}\"{{ knp_menu.attributes(item.linkAttributes) }}>{{ block('label') }}</a>{% endblock %}

{% block spanElement %}{% import _self as knp_menu %}<span{{ knp_menu.attributes(item.labelAttributes) }}>{{ block('label') }}</span>{% endblock %}

{% block label %}{% if options.allow_safe_labels and item.getExtra('safe_label', false) %}{{ item.label|raw }}{% else %}{{ item.label }}{% endif %}{% endblock %}
", "knp_menu.html.twig", "/home/henne/Desktop/Project/opium/vendor/knplabs/knp-menu/src/Knp/Menu/Resources/views/knp_menu.html.twig");
    }
}
