<?php

/* @MopaBootstrap/Navbar/navbar.html.twig */
class __TwigTemplate_7f88b984c30231893c2d3d1c3189e8082d38893f92e2f24c5aa80ddfb611b98c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'header' => array($this, 'block_header'),
            'toggle' => array($this, 'block_toggle'),
            'brand' => array($this, 'block_brand'),
            'menu_container' => array($this, 'block_menu_container'),
            'menu' => array($this, 'block_menu'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_24dddb4389ff3bcb7a78a99935085a3780eb2c2b7083d11038c08d45074671b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_24dddb4389ff3bcb7a78a99935085a3780eb2c2b7083d11038c08d45074671b5->enter($__internal_24dddb4389ff3bcb7a78a99935085a3780eb2c2b7083d11038c08d45074671b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@MopaBootstrap/Navbar/navbar.html.twig"));

        $__internal_344b9d859188fffbf2ee6595359e1702fe695ed9febefca3af563ade0846f5b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_344b9d859188fffbf2ee6595359e1702fe695ed9febefca3af563ade0846f5b5->enter($__internal_344b9d859188fffbf2ee6595359e1702fe695ed9febefca3af563ade0846f5b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@MopaBootstrap/Navbar/navbar.html.twig"));

        // line 1
        echo "<div ";
        if (((array_key_exists("id", $context)) ? (_twig_default_filter(($context["id"] ?? $this->getContext($context, "id")), false)) : (false))) {
            echo "id=\"";
            echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
            echo "\" ";
        }
        echo "role=\"navigation\" class=\"navbar";
        echo ((((array_key_exists("inverse", $context)) ? (_twig_default_filter(($context["inverse"] ?? $this->getContext($context, "inverse")), false)) : (false))) ? (" navbar-inverse") : (" navbar-default"));
        echo ((((array_key_exists("fixedTop", $context)) ? (_twig_default_filter(($context["fixedTop"] ?? $this->getContext($context, "fixedTop")), false)) : (false))) ? (" navbar-fixed-top") : (""));
        echo ((((array_key_exists("staticTop", $context)) ? (_twig_default_filter(($context["staticTop"] ?? $this->getContext($context, "staticTop")), false)) : (false))) ? (" navbar-static-top") : (""));
        echo ((((array_key_exists("fixedBottom", $context)) ? (_twig_default_filter(($context["fixedBottom"] ?? $this->getContext($context, "fixedBottom")), false)) : (false))) ? (" navbar-fixed-bottom") : (""));
        echo ((((array_key_exists("staticBottom", $context)) ? (_twig_default_filter(($context["staticBottom"] ?? $this->getContext($context, "staticBottom")), false)) : (false))) ? (" navbar-static-bottom") : (""));
        echo "\">
    <div class=\"container";
        // line 2
        echo ((((array_key_exists("fluid", $context)) ? (_twig_default_filter(($context["fluid"] ?? $this->getContext($context, "fluid")), false)) : (false))) ? ("-fluid") : (""));
        echo "\">
        ";
        // line 3
        $this->displayBlock('header', $context, $blocks);
        // line 16
        echo "        ";
        $this->displayBlock('menu_container', $context, $blocks);
        // line 21
        echo "    </div>
</div>
";
        
        $__internal_24dddb4389ff3bcb7a78a99935085a3780eb2c2b7083d11038c08d45074671b5->leave($__internal_24dddb4389ff3bcb7a78a99935085a3780eb2c2b7083d11038c08d45074671b5_prof);

        
        $__internal_344b9d859188fffbf2ee6595359e1702fe695ed9febefca3af563ade0846f5b5->leave($__internal_344b9d859188fffbf2ee6595359e1702fe695ed9febefca3af563ade0846f5b5_prof);

    }

    // line 3
    public function block_header($context, array $blocks = array())
    {
        $__internal_fb7e68572f783f60b02d50d5f92405a881b7e4d4c1aa1ad9bd507be561c86df2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb7e68572f783f60b02d50d5f92405a881b7e4d4c1aa1ad9bd507be561c86df2->enter($__internal_fb7e68572f783f60b02d50d5f92405a881b7e4d4c1aa1ad9bd507be561c86df2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_62eba67713e62aa2e50be9b196f4fcde99ae6f8b20718c0c0cb8439de2c4889a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_62eba67713e62aa2e50be9b196f4fcde99ae6f8b20718c0c0cb8439de2c4889a->enter($__internal_62eba67713e62aa2e50be9b196f4fcde99ae6f8b20718c0c0cb8439de2c4889a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 4
        echo "        <div class=\"navbar-header\">
            ";
        // line 5
        $this->displayBlock('toggle', $context, $blocks);
        // line 13
        echo "            ";
        $this->displayBlock('brand', $context, $blocks);
        // line 14
        echo "        </div>
        ";
        
        $__internal_62eba67713e62aa2e50be9b196f4fcde99ae6f8b20718c0c0cb8439de2c4889a->leave($__internal_62eba67713e62aa2e50be9b196f4fcde99ae6f8b20718c0c0cb8439de2c4889a_prof);

        
        $__internal_fb7e68572f783f60b02d50d5f92405a881b7e4d4c1aa1ad9bd507be561c86df2->leave($__internal_fb7e68572f783f60b02d50d5f92405a881b7e4d4c1aa1ad9bd507be561c86df2_prof);

    }

    // line 5
    public function block_toggle($context, array $blocks = array())
    {
        $__internal_3e36470e0c4d30fb3eb4d43d5232e46bde4e9551535115a1814d377a8dfdca71 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e36470e0c4d30fb3eb4d43d5232e46bde4e9551535115a1814d377a8dfdca71->enter($__internal_3e36470e0c4d30fb3eb4d43d5232e46bde4e9551535115a1814d377a8dfdca71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toggle"));

        $__internal_4482473f4c582d606ecd64cc7a6239e3acc9d8735c256b9af21961875c38e6bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4482473f4c582d606ecd64cc7a6239e3acc9d8735c256b9af21961875c38e6bb->enter($__internal_4482473f4c582d606ecd64cc7a6239e3acc9d8735c256b9af21961875c38e6bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toggle"));

        // line 6
        echo "            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-responsive-collapse";
        if (((array_key_exists("id", $context)) ? (_twig_default_filter(($context["id"] ?? $this->getContext($context, "id")), false)) : (false))) {
            echo "-";
            echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        }
        echo "\" >
            <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            ";
        
        $__internal_4482473f4c582d606ecd64cc7a6239e3acc9d8735c256b9af21961875c38e6bb->leave($__internal_4482473f4c582d606ecd64cc7a6239e3acc9d8735c256b9af21961875c38e6bb_prof);

        
        $__internal_3e36470e0c4d30fb3eb4d43d5232e46bde4e9551535115a1814d377a8dfdca71->leave($__internal_3e36470e0c4d30fb3eb4d43d5232e46bde4e9551535115a1814d377a8dfdca71_prof);

    }

    // line 13
    public function block_brand($context, array $blocks = array())
    {
        $__internal_f5af391422fea52de3ce9da78d865052a33785732b0e70d687d606ea86995f83 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f5af391422fea52de3ce9da78d865052a33785732b0e70d687d606ea86995f83->enter($__internal_f5af391422fea52de3ce9da78d865052a33785732b0e70d687d606ea86995f83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "brand"));

        $__internal_ac94a449b6fd3e64ae78f10ec69921c831fb068aa15ff2e0a686096de4036d50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac94a449b6fd3e64ae78f10ec69921c831fb068aa15ff2e0a686096de4036d50->enter($__internal_ac94a449b6fd3e64ae78f10ec69921c831fb068aa15ff2e0a686096de4036d50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "brand"));

        
        $__internal_ac94a449b6fd3e64ae78f10ec69921c831fb068aa15ff2e0a686096de4036d50->leave($__internal_ac94a449b6fd3e64ae78f10ec69921c831fb068aa15ff2e0a686096de4036d50_prof);

        
        $__internal_f5af391422fea52de3ce9da78d865052a33785732b0e70d687d606ea86995f83->leave($__internal_f5af391422fea52de3ce9da78d865052a33785732b0e70d687d606ea86995f83_prof);

    }

    // line 16
    public function block_menu_container($context, array $blocks = array())
    {
        $__internal_42eabba4a6d6b9c445e48dc00c349bc2095420e0e33730848ce66ebadafd52c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42eabba4a6d6b9c445e48dc00c349bc2095420e0e33730848ce66ebadafd52c4->enter($__internal_42eabba4a6d6b9c445e48dc00c349bc2095420e0e33730848ce66ebadafd52c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu_container"));

        $__internal_c5b0245316d409856bd308ddb7eb92c2ebd92d3d72b8d0286741f36b8facb32c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5b0245316d409856bd308ddb7eb92c2ebd92d3d72b8d0286741f36b8facb32c->enter($__internal_c5b0245316d409856bd308ddb7eb92c2ebd92d3d72b8d0286741f36b8facb32c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu_container"));

        // line 17
        echo "        <div class=\"collapse navbar-collapse navbar-responsive-collapse";
        if (((array_key_exists("id", $context)) ? (_twig_default_filter(($context["id"] ?? $this->getContext($context, "id")), false)) : (false))) {
            echo "-";
            echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        }
        echo "\">
            ";
        // line 18
        $this->displayBlock('menu', $context, $blocks);
        // line 19
        echo "        </div>
        ";
        
        $__internal_c5b0245316d409856bd308ddb7eb92c2ebd92d3d72b8d0286741f36b8facb32c->leave($__internal_c5b0245316d409856bd308ddb7eb92c2ebd92d3d72b8d0286741f36b8facb32c_prof);

        
        $__internal_42eabba4a6d6b9c445e48dc00c349bc2095420e0e33730848ce66ebadafd52c4->leave($__internal_42eabba4a6d6b9c445e48dc00c349bc2095420e0e33730848ce66ebadafd52c4_prof);

    }

    // line 18
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b2fabc47277e7a2498cb6fee96f437e621fea4d8d5472a3dd844b5e406a83b4d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2fabc47277e7a2498cb6fee96f437e621fea4d8d5472a3dd844b5e406a83b4d->enter($__internal_b2fabc47277e7a2498cb6fee96f437e621fea4d8d5472a3dd844b5e406a83b4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_3bcc983a95aea9334b5fef81353da580984b048f3353ab1b7a38d24edea015de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3bcc983a95aea9334b5fef81353da580984b048f3353ab1b7a38d24edea015de->enter($__internal_3bcc983a95aea9334b5fef81353da580984b048f3353ab1b7a38d24edea015de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        
        $__internal_3bcc983a95aea9334b5fef81353da580984b048f3353ab1b7a38d24edea015de->leave($__internal_3bcc983a95aea9334b5fef81353da580984b048f3353ab1b7a38d24edea015de_prof);

        
        $__internal_b2fabc47277e7a2498cb6fee96f437e621fea4d8d5472a3dd844b5e406a83b4d->leave($__internal_b2fabc47277e7a2498cb6fee96f437e621fea4d8d5472a3dd844b5e406a83b4d_prof);

    }

    public function getTemplateName()
    {
        return "@MopaBootstrap/Navbar/navbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 18,  160 => 19,  158 => 18,  150 => 17,  141 => 16,  124 => 13,  103 => 6,  94 => 5,  83 => 14,  80 => 13,  78 => 5,  75 => 4,  66 => 3,  54 => 21,  51 => 16,  49 => 3,  45 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div {% if id|default(false) %}id=\"{{ id }}\" {% endif %}role=\"navigation\" class=\"navbar{{ inverse|default(false) ? ' navbar-inverse' : ' navbar-default' }}{{ fixedTop|default(false) ? ' navbar-fixed-top' : '' }}{{ staticTop|default(false) ? ' navbar-static-top' : '' }}{{ fixedBottom|default(false) ? ' navbar-fixed-bottom' : '' }}{{ staticBottom|default(false) ? ' navbar-static-bottom' : '' }}\">
    <div class=\"container{{ fluid|default(false) ? '-fluid' : '' }}\">
        {% block header %}
        <div class=\"navbar-header\">
            {% block toggle %}
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-responsive-collapse{% if id|default(false) %}-{{ id }}{% endif %}\" >
            <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            {% endblock toggle %}
            {% block brand %}{% endblock brand %}
        </div>
        {% endblock header %}
        {% block menu_container %}
        <div class=\"collapse navbar-collapse navbar-responsive-collapse{% if id|default(false) %}-{{ id }}{% endif %}\">
            {% block menu %}{% endblock %}
        </div>
        {% endblock %}
    </div>
</div>
", "@MopaBootstrap/Navbar/navbar.html.twig", "/home/henne/Desktop/Project/opium/vendor/mopa/bootstrap-bundle/Mopa/Bundle/BootstrapBundle/Resources/views/Navbar/navbar.html.twig");
    }
}
