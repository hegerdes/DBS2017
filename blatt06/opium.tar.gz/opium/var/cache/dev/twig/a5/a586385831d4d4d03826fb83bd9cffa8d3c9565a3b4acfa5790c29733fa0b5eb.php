<?php

/* MopaBootstrapBundle::flash.html.twig */
class __TwigTemplate_c1c9f538c4ae14bbfb37812a464e855ac25a61d0d8fa6c1ce58bce1ddd6a8992 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e9b796494e99197f9eb943afb3fcf6d3389a2dc15d61524bd3f3809f8e8b8a1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e9b796494e99197f9eb943afb3fcf6d3389a2dc15d61524bd3f3809f8e8b8a1->enter($__internal_4e9b796494e99197f9eb943afb3fcf6d3389a2dc15d61524bd3f3809f8e8b8a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle::flash.html.twig"));

        $__internal_2d94244699975cfb96e44a913b06809d5bc53477263c2caea1a826b41e1c6266 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d94244699975cfb96e44a913b06809d5bc53477263c2caea1a826b41e1c6266->enter($__internal_2d94244699975cfb96e44a913b06809d5bc53477263c2caea1a826b41e1c6266_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle::flash.html.twig"));

        // line 13
        echo "
";
        // line 32
        echo "
";
        
        $__internal_4e9b796494e99197f9eb943afb3fcf6d3389a2dc15d61524bd3f3809f8e8b8a1->leave($__internal_4e9b796494e99197f9eb943afb3fcf6d3389a2dc15d61524bd3f3809f8e8b8a1_prof);

        
        $__internal_2d94244699975cfb96e44a913b06809d5bc53477263c2caea1a826b41e1c6266->leave($__internal_2d94244699975cfb96e44a913b06809d5bc53477263c2caea1a826b41e1c6266_prof);

    }

    // line 1
    public function getflash($__type__ = null, $__message__ = null, $__close__ = null, $__use_raw__ = null, $__class__ = null, $__domain__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "type" => $__type__,
            "message" => $__message__,
            "close" => $__close__,
            "use_raw" => $__use_raw__,
            "class" => $__class__,
            "domain" => $__domain__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_467dd8dc5a91e39a3eacaa6757bab8eb37455df82fff53c47dd1c7f7f10f9473 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_467dd8dc5a91e39a3eacaa6757bab8eb37455df82fff53c47dd1c7f7f10f9473->enter($__internal_467dd8dc5a91e39a3eacaa6757bab8eb37455df82fff53c47dd1c7f7f10f9473_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "flash"));

            $__internal_a242623edd71313c0c04f6df27a077e5e253a6b89c223605b03acd517eb82f3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_a242623edd71313c0c04f6df27a077e5e253a6b89c223605b03acd517eb82f3c->enter($__internal_a242623edd71313c0c04f6df27a077e5e253a6b89c223605b03acd517eb82f3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "flash"));

            // line 2
            echo "    <div class=\"alert";
            echo twig_escape_filter($this->env, ((($context["type"] ?? $this->getContext($context, "type"))) ? ((" alert-" . ($context["type"] ?? $this->getContext($context, "type")))) : ("")), "html", null, true);
            echo " fade in ";
            echo twig_escape_filter($this->env, ((array_key_exists("class", $context)) ? (_twig_default_filter(($context["class"] ?? $this->getContext($context, "class")), "")) : ("")), "html", null, true);
            echo " ";
            if (((array_key_exists("close", $context)) ? (_twig_default_filter(($context["close"] ?? $this->getContext($context, "close")), false)) : (false))) {
                echo "alert-dismissible";
            }
            echo "\">
    ";
            // line 3
            if (((array_key_exists("close", $context)) ? (_twig_default_filter(($context["close"] ?? $this->getContext($context, "close")), false)) : (false))) {
                // line 4
                echo "        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
    ";
            }
            // line 6
            echo "    ";
            if (((array_key_exists("use_raw", $context)) ? (_twig_default_filter(($context["use_raw"] ?? $this->getContext($context, "use_raw")), false)) : (false))) {
                // line 7
                echo "        ";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["message"] ?? $this->getContext($context, "message")), array(), ((array_key_exists("domain", $context)) ? (_twig_default_filter(($context["domain"] ?? $this->getContext($context, "domain")), "messages")) : ("messages")));
                echo "
    ";
            } else {
                // line 9
                echo "        ";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["message"] ?? $this->getContext($context, "message")), array(), ((array_key_exists("domain", $context)) ? (_twig_default_filter(($context["domain"] ?? $this->getContext($context, "domain")), "messages")) : ("messages"))), "html", null, true);
                echo "
    ";
            }
            // line 11
            echo "    </div>
";
            
            $__internal_a242623edd71313c0c04f6df27a077e5e253a6b89c223605b03acd517eb82f3c->leave($__internal_a242623edd71313c0c04f6df27a077e5e253a6b89c223605b03acd517eb82f3c_prof);

            
            $__internal_467dd8dc5a91e39a3eacaa6757bab8eb37455df82fff53c47dd1c7f7f10f9473->leave($__internal_467dd8dc5a91e39a3eacaa6757bab8eb37455df82fff53c47dd1c7f7f10f9473_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    // line 14
    public function getadvanced_flash($__type__ = null, $__heading__ = null, $__message__ = null, $__close_tag__ = null, $__use_raw__ = null, $__class__ = null, $__domain__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "type" => $__type__,
            "heading" => $__heading__,
            "message" => $__message__,
            "close_tag" => $__close_tag__,
            "use_raw" => $__use_raw__,
            "class" => $__class__,
            "domain" => $__domain__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_a73c6437ad3642fea73cef0ecba91adac151531c5bcf8998925d3b87647e4112 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_a73c6437ad3642fea73cef0ecba91adac151531c5bcf8998925d3b87647e4112->enter($__internal_a73c6437ad3642fea73cef0ecba91adac151531c5bcf8998925d3b87647e4112_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "advanced_flash"));

            $__internal_61bbe62e5c6427394fa5f555516cc5fb73d5c300d64290245b08876b6c999283 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_61bbe62e5c6427394fa5f555516cc5fb73d5c300d64290245b08876b6c999283->enter($__internal_61bbe62e5c6427394fa5f555516cc5fb73d5c300d64290245b08876b6c999283_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "advanced_flash"));

            // line 15
            echo "    <div class=\"alert";
            echo twig_escape_filter($this->env, ((($context["type"] ?? $this->getContext($context, "type"))) ? ((" alert-" . ($context["type"] ?? $this->getContext($context, "type")))) : ("")), "html", null, true);
            echo " fade in ";
            echo twig_escape_filter($this->env, ((array_key_exists("class", $context)) ? (_twig_default_filter(($context["class"] ?? $this->getContext($context, "class")), "")) : ("")), "html", null, true);
            echo " ";
            if (((array_key_exists("close_tag", $context)) ? (_twig_default_filter(($context["close_tag"] ?? $this->getContext($context, "close_tag")), false)) : (false))) {
                echo "alert-dismissible";
            }
            echo "\">
    ";
            // line 16
            if (((array_key_exists("close_tag", $context)) ? (_twig_default_filter(($context["close_tag"] ?? $this->getContext($context, "close_tag")), false)) : (false))) {
                // line 17
                echo "        ";
                if ((($context["close_tag"] ?? $this->getContext($context, "close_tag")) == "true")) {
                    // line 18
                    echo "            ";
                    $context["close_tag"] = "a";
                    // line 19
                    echo "        ";
                }
                // line 20
                echo "        <";
                echo twig_escape_filter($this->env, ($context["close_tag"] ?? $this->getContext($context, "close_tag")), "html", null, true);
                echo " class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\" ";
                if ((($context["close_tag"] ?? $this->getContext($context, "close_tag")) == "a")) {
                    echo "href=\"#\"";
                } elseif ((($context["close_tag"] ?? $this->getContext($context, "close_tag")) == "button")) {
                    echo "type=\"button\"";
                }
                echo ">&times;</";
                echo twig_escape_filter($this->env, ($context["close_tag"] ?? $this->getContext($context, "close_tag")), "html", null, true);
                echo ">
    ";
            }
            // line 22
            echo "    ";
            if (((array_key_exists("heading", $context)) ? (_twig_default_filter(($context["heading"] ?? $this->getContext($context, "heading")), false)) : (false))) {
                // line 23
                echo "    <h4 class=\"alert-heading\">";
                echo twig_escape_filter($this->env, ($context["heading"] ?? $this->getContext($context, "heading")), "html", null, true);
                echo "</h4>
    ";
            }
            // line 25
            echo "    ";
            if (((array_key_exists("use_raw", $context)) ? (_twig_default_filter(($context["use_raw"] ?? $this->getContext($context, "use_raw")), false)) : (false))) {
                // line 26
                echo "        ";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["message"] ?? $this->getContext($context, "message")), array(), ((array_key_exists("domain", $context)) ? (_twig_default_filter(($context["domain"] ?? $this->getContext($context, "domain")), "messages")) : ("messages")));
                echo "
    ";
            } else {
                // line 28
                echo "        ";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["message"] ?? $this->getContext($context, "message")), array(), ((array_key_exists("domain", $context)) ? (_twig_default_filter(($context["domain"] ?? $this->getContext($context, "domain")), "messages")) : ("messages"))), "html", null, true);
                echo "
    ";
            }
            // line 30
            echo "    </div>
";
            
            $__internal_61bbe62e5c6427394fa5f555516cc5fb73d5c300d64290245b08876b6c999283->leave($__internal_61bbe62e5c6427394fa5f555516cc5fb73d5c300d64290245b08876b6c999283_prof);

            
            $__internal_a73c6437ad3642fea73cef0ecba91adac151531c5bcf8998925d3b87647e4112->leave($__internal_a73c6437ad3642fea73cef0ecba91adac151531c5bcf8998925d3b87647e4112_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    // line 33
    public function getsession_flash($__close__ = null, $__use_raw__ = null, $__class__ = null, $__domain__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "close" => $__close__,
            "use_raw" => $__use_raw__,
            "class" => $__class__,
            "domain" => $__domain__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_ece2112fab891ba37700f6005e8dc5a53937e5339133cafbd6b4ee7b87431f68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
            $__internal_ece2112fab891ba37700f6005e8dc5a53937e5339133cafbd6b4ee7b87431f68->enter($__internal_ece2112fab891ba37700f6005e8dc5a53937e5339133cafbd6b4ee7b87431f68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "session_flash"));

            $__internal_4a3dd88a6204e4cd9e31a514d54cc735e573bb17daad7cb0794d010759ca18e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
            $__internal_4a3dd88a6204e4cd9e31a514d54cc735e573bb17daad7cb0794d010759ca18e5->enter($__internal_4a3dd88a6204e4cd9e31a514d54cc735e573bb17daad7cb0794d010759ca18e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "session_flash"));

            // line 34
            echo "    ";
            $context["flash_messages"] = $this;
            // line 35
            echo "
    ";
            // line 36
            if ((twig_length_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "peekAll", array())) > 0)) {
                // line 37
                echo "        ";
                $context["mapping"] = twig_array_merge($this->env->getExtension('Mopa\Bundle\BootstrapBundle\Twig\FlashExtension')->getMapping(), array("fos_user_success" => "success"));
                // line 38
                echo "        ";
                $context["flashes"] = array();
                // line 39
                echo "
        ";
                // line 40
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_array_keys_filter(($context["mapping"] ?? $this->getContext($context, "mapping"))));
                foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
                    // line 41
                    echo "            ";
                    $context["flashes"] = twig_array_merge(($context["flashes"] ?? $this->getContext($context, "flashes")), array($context["type"] => $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => $context["type"]), "method")));
                    // line 42
                    echo "        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 43
                echo "
        ";
                // line 44
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["flashes"] ?? $this->getContext($context, "flashes")));
                foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                    // line 45
                    echo "            ";
                    if (($context["type"] == "fos_user_success")) {
                        // line 46
                        echo "                ";
                        $context["domain"] = "FOSUserBundle";
                        // line 47
                        echo "            ";
                    }
                    // line 48
                    echo "            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["messages"]);
                    foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                        // line 49
                        echo "                ";
                        echo $context["flash_messages"]->getflash($this->getAttribute(($context["mapping"] ?? $this->getContext($context, "mapping")), $context["type"], array(), "array"), $context["message"], ($context["close"] ?? $this->getContext($context, "close")), ($context["use_raw"] ?? $this->getContext($context, "use_raw")), ($context["class"] ?? $this->getContext($context, "class")), ($context["domain"] ?? $this->getContext($context, "domain")));
                        echo "
            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 51
                    echo "        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 52
                echo "    ";
            }
            
            $__internal_4a3dd88a6204e4cd9e31a514d54cc735e573bb17daad7cb0794d010759ca18e5->leave($__internal_4a3dd88a6204e4cd9e31a514d54cc735e573bb17daad7cb0794d010759ca18e5_prof);

            
            $__internal_ece2112fab891ba37700f6005e8dc5a53937e5339133cafbd6b4ee7b87431f68->leave($__internal_ece2112fab891ba37700f6005e8dc5a53937e5339133cafbd6b4ee7b87431f68_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        } catch (Throwable $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "MopaBootstrapBundle::flash.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  309 => 52,  303 => 51,  294 => 49,  289 => 48,  286 => 47,  283 => 46,  280 => 45,  276 => 44,  273 => 43,  267 => 42,  264 => 41,  260 => 40,  257 => 39,  254 => 38,  251 => 37,  249 => 36,  246 => 35,  243 => 34,  222 => 33,  200 => 30,  194 => 28,  188 => 26,  185 => 25,  179 => 23,  176 => 22,  162 => 20,  159 => 19,  156 => 18,  153 => 17,  151 => 16,  140 => 15,  116 => 14,  94 => 11,  88 => 9,  82 => 7,  79 => 6,  75 => 4,  73 => 3,  62 => 2,  39 => 1,  28 => 32,  25 => 13,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro flash(type, message, close, use_raw, class, domain) %}
    <div class=\"alert{{ type ? ' alert-'~type : '' }} fade in {{ class|default('') }} {% if close|default(false) %}alert-dismissible{% endif %}\">
    {% if close|default(false) %}
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
    {% endif %}
    {% if use_raw|default(false) %}
        {{ message|trans({}, domain|default('messages'))|raw }}
    {% else %}
        {{ message|trans({}, domain|default('messages')) }}
    {% endif %}
    </div>
{% endmacro %}

{% macro advanced_flash(type, heading, message, close_tag, use_raw, class, domain) %}
    <div class=\"alert{{ type ? ' alert-'~type : '' }} fade in {{ class|default('') }} {% if close_tag|default(false) %}alert-dismissible{% endif %}\">
    {% if close_tag|default(false) %}
        {% if close_tag == 'true' %}
            {% set close_tag = 'a' %}
        {% endif %}
        <{{ close_tag }} class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\" {% if close_tag == 'a' %}href=\"#\"{% elseif close_tag =='button' %}type=\"button\"{% endif %}>&times;</{{ close_tag }}>
    {% endif %}
    {% if heading|default(false) %}
    <h4 class=\"alert-heading\">{{ heading }}</h4>
    {% endif %}
    {% if use_raw|default(false) %}
        {{ message|trans({}, domain|default('messages'))|raw }}
    {% else %}
        {{ message|trans({}, domain|default('messages')) }}
    {% endif %}
    </div>
{% endmacro %}

{% macro session_flash(close, use_raw, class, domain) %}
    {% import _self as flash_messages %}

    {% if app.session.flashbag.peekAll|length > 0 %}
        {% set mapping = mopa_bootstrap_flash_mapping()|merge({'fos_user_success':'success'}) %}
        {% set flashes = {} %}

        {% for type in mapping|keys %}
            {% set flashes = flashes | merge({ (type) : app.session.flashbag.get(type) }) %}
        {% endfor %}

        {% for type, messages in flashes %}
            {% if type == 'fos_user_success' %}
                {% set domain = 'FOSUserBundle' %}
            {% endif %}
            {% for message in messages %}
                {{ flash_messages.flash(mapping[type], message, close, use_raw, class, domain) }}
            {% endfor %}
        {% endfor %}
    {% endif %}
{% endmacro %}
", "MopaBootstrapBundle::flash.html.twig", "/home/henne/Desktop/Project/opium/vendor/mopa/bootstrap-bundle/Mopa/Bundle/BootstrapBundle/Resources/views/flash.html.twig");
    }
}
