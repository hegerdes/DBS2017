<?php

/* OpiumBundle:Examiner:index.html.twig */
class __TwigTemplate_f4342d6412eebcc30635b92c9c5c910f8ea281d092cebff72d700f7eff3474f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "OpiumBundle:Examiner:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'headline' => array($this, 'block_headline'),
            'content_row' => array($this, 'block_content_row'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a85333a0977900d3183081c11d88b4c3985f00014e38b48af9f15bf549f8a460 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a85333a0977900d3183081c11d88b4c3985f00014e38b48af9f15bf549f8a460->enter($__internal_a85333a0977900d3183081c11d88b4c3985f00014e38b48af9f15bf549f8a460_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OpiumBundle:Examiner:index.html.twig"));

        $__internal_888ce442fdbca7a394f31c43052b34856f305623b6edd54c3aef00f9316f5d1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_888ce442fdbca7a394f31c43052b34856f305623b6edd54c3aef00f9316f5d1f->enter($__internal_888ce442fdbca7a394f31c43052b34856f305623b6edd54c3aef00f9316f5d1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OpiumBundle:Examiner:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a85333a0977900d3183081c11d88b4c3985f00014e38b48af9f15bf549f8a460->leave($__internal_a85333a0977900d3183081c11d88b4c3985f00014e38b48af9f15bf549f8a460_prof);

        
        $__internal_888ce442fdbca7a394f31c43052b34856f305623b6edd54c3aef00f9316f5d1f->leave($__internal_888ce442fdbca7a394f31c43052b34856f305623b6edd54c3aef00f9316f5d1f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_bea0b82ab36420bb6908f910977f584ada059b1632bd46617814cbba6ca2d687 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bea0b82ab36420bb6908f910977f584ada059b1632bd46617814cbba6ca2d687->enter($__internal_bea0b82ab36420bb6908f910977f584ada059b1632bd46617814cbba6ca2d687_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_02d256304316a35e7c9169a752f89ec459d45d3b93ea2a4ef7a11c51ca451f5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02d256304316a35e7c9169a752f89ec459d45d3b93ea2a4ef7a11c51ca451f5c->enter($__internal_02d256304316a35e7c9169a752f89ec459d45d3b93ea2a4ef7a11c51ca451f5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Klausuren";
        
        $__internal_02d256304316a35e7c9169a752f89ec459d45d3b93ea2a4ef7a11c51ca451f5c->leave($__internal_02d256304316a35e7c9169a752f89ec459d45d3b93ea2a4ef7a11c51ca451f5c_prof);

        
        $__internal_bea0b82ab36420bb6908f910977f584ada059b1632bd46617814cbba6ca2d687->leave($__internal_bea0b82ab36420bb6908f910977f584ada059b1632bd46617814cbba6ca2d687_prof);

    }

    // line 4
    public function block_headline($context, array $blocks = array())
    {
        $__internal_1fffa7a6de6dc587728b9ba89a5f0651d670f0d8ebd38286f97e606660922f5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1fffa7a6de6dc587728b9ba89a5f0651d670f0d8ebd38286f97e606660922f5b->enter($__internal_1fffa7a6de6dc587728b9ba89a5f0651d670f0d8ebd38286f97e606660922f5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        $__internal_7b63c75954ffa00f29c2cd5371e9f512f47701b57ac897378a1ab1d179c02b94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b63c75954ffa00f29c2cd5371e9f512f47701b57ac897378a1ab1d179c02b94->enter($__internal_7b63c75954ffa00f29c2cd5371e9f512f47701b57ac897378a1ab1d179c02b94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        echo "Klausuren";
        
        $__internal_7b63c75954ffa00f29c2cd5371e9f512f47701b57ac897378a1ab1d179c02b94->leave($__internal_7b63c75954ffa00f29c2cd5371e9f512f47701b57ac897378a1ab1d179c02b94_prof);

        
        $__internal_1fffa7a6de6dc587728b9ba89a5f0651d670f0d8ebd38286f97e606660922f5b->leave($__internal_1fffa7a6de6dc587728b9ba89a5f0651d670f0d8ebd38286f97e606660922f5b_prof);

    }

    // line 6
    public function block_content_row($context, array $blocks = array())
    {
        $__internal_6cd4d2927f7ca33add4aaa7dd71ed8fc567116601a0318eedc08daf04223fd86 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cd4d2927f7ca33add4aaa7dd71ed8fc567116601a0318eedc08daf04223fd86->enter($__internal_6cd4d2927f7ca33add4aaa7dd71ed8fc567116601a0318eedc08daf04223fd86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        $__internal_d542989348baa47fcb70b7da666c08c2539bd952303053311a8f3ece903854e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d542989348baa47fcb70b7da666c08c2539bd952303053311a8f3ece903854e7->enter($__internal_d542989348baa47fcb70b7da666c08c2539bd952303053311a8f3ece903854e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        // line 7
        echo "    <table class=\"table table-condensed\">
        <thead>
        <tr>
            <th>Kurs</th>
            <th>Raum</th>
            <th>Datum</th>
            <th>Uhrzeit</th>
            <th>Dauer</th>
            <th>Art der Prüfung</th>
            <th>Termin</th>
            <th>Semester</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["exams"] ?? $this->getContext($context, "exams")));
        foreach ($context['_seq'] as $context["_key"] => $context["exam"]) {
            // line 22
            echo "
            <tr>
                <td><a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("examiner_details", array("exam" => $this->getAttribute($context["exam"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["exam"], "subject", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["exam"], "room", array()), "building", array()), "number", array()), "html", null, true);
            echo "/";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["exam"], "room", array()), "number", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 26
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["exam"], "date", array()), "d.m.Y"), "html", null, true);
            echo "</td>
                <td>";
            // line 27
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["exam"], "date", array()), "H:i"), "html", null, true);
            echo "</td>
                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["exam"], "duration", array()), "html", null, true);
            echo "</td>
                <td>
                    ";
            // line 30
            if (($this->getAttribute($context["exam"], "type", array()) == twig_constant("OpiumBundle\\Entity\\ExamType::WRITTEN"))) {
                // line 31
                echo "                        schriftlich
                    ";
            } elseif (($this->getAttribute(            // line 32
$context["exam"], "type", array()) == twig_constant("OpiumBundle\\Entity\\ExamType::ORAL"))) {
                // line 33
                echo "                        mündlich
                    ";
            } else {
                // line 35
                echo "                        nocht nicht festgelegt
                    ";
            }
            // line 37
            echo "                </td>
                <td>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["exam"], "appointment", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["exam"], "semester", array()), "identifier", array()), "html", null, true);
            echo "</td>
            </tr>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['exam'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "        </tbody>
    </table>
";
        
        $__internal_d542989348baa47fcb70b7da666c08c2539bd952303053311a8f3ece903854e7->leave($__internal_d542989348baa47fcb70b7da666c08c2539bd952303053311a8f3ece903854e7_prof);

        
        $__internal_6cd4d2927f7ca33add4aaa7dd71ed8fc567116601a0318eedc08daf04223fd86->leave($__internal_6cd4d2927f7ca33add4aaa7dd71ed8fc567116601a0318eedc08daf04223fd86_prof);

    }

    public function getTemplateName()
    {
        return "OpiumBundle:Examiner:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 43,  158 => 39,  154 => 38,  151 => 37,  147 => 35,  143 => 33,  141 => 32,  138 => 31,  136 => 30,  131 => 28,  127 => 27,  123 => 26,  117 => 25,  111 => 24,  107 => 22,  103 => 21,  87 => 7,  78 => 6,  60 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Klausuren{% endblock %}
{% block headline %}Klausuren{% endblock headline %}

{% block content_row %}
    <table class=\"table table-condensed\">
        <thead>
        <tr>
            <th>Kurs</th>
            <th>Raum</th>
            <th>Datum</th>
            <th>Uhrzeit</th>
            <th>Dauer</th>
            <th>Art der Prüfung</th>
            <th>Termin</th>
            <th>Semester</th>
        </tr>
        </thead>
        <tbody>
        {% for exam in exams %}

            <tr>
                <td><a href=\"{{ path('examiner_details', {'exam': exam.id}) }}\">{{ exam.subject }}</a></td>
                <td>{{ exam.room.building.number }}/{{ exam.room.number }}</td>
                <td>{{ exam.date|date(\"d.m.Y\") }}</td>
                <td>{{ exam.date|date(\"H:i\") }}</td>
                <td>{{ exam.duration }}</td>
                <td>
                    {% if exam.type == constant('OpiumBundle\\\\Entity\\\\ExamType::WRITTEN') %}
                        schriftlich
                    {% elseif exam.type == constant('OpiumBundle\\\\Entity\\\\ExamType::ORAL') %}
                        mündlich
                    {% else %}
                        nocht nicht festgelegt
                    {% endif %}
                </td>
                <td>{{ exam.appointment }}</td>
                <td>{{ exam.semester.identifier }}</td>
            </tr>

        {% endfor %}
        </tbody>
    </table>
{% endblock content_row %}
", "OpiumBundle:Examiner:index.html.twig", "/home/henne/Desktop/Project/opium/src/OpiumBundle/Resources/views/Examiner/index.html.twig");
    }
}
