<?php

/* MopaBootstrapBundle:Menu:menu.html.twig */
class __TwigTemplate_234aa45eda87187aa9b2f4f1e461cf31f3760ace4e13ef9c3f04ecec83516c06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("KnpMenuBundle::menu.html.twig", "MopaBootstrapBundle:Menu:menu.html.twig", 1);
        $this->blocks = array(
            'linkElement' => array($this, 'block_linkElement'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "KnpMenuBundle::menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e7f3c3efc5bab423439fb55bcde52a3d7bdfb01287a127123f8bca5c01c4a63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e7f3c3efc5bab423439fb55bcde52a3d7bdfb01287a127123f8bca5c01c4a63->enter($__internal_5e7f3c3efc5bab423439fb55bcde52a3d7bdfb01287a127123f8bca5c01c4a63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle:Menu:menu.html.twig"));

        $__internal_987156d34759998e469c4031c4d9cb391f0224e9d97e234893bdbfcda19a6fc3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_987156d34759998e469c4031c4d9cb391f0224e9d97e234893bdbfcda19a6fc3->enter($__internal_987156d34759998e469c4031c4d9cb391f0224e9d97e234893bdbfcda19a6fc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MopaBootstrapBundle:Menu:menu.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5e7f3c3efc5bab423439fb55bcde52a3d7bdfb01287a127123f8bca5c01c4a63->leave($__internal_5e7f3c3efc5bab423439fb55bcde52a3d7bdfb01287a127123f8bca5c01c4a63_prof);

        
        $__internal_987156d34759998e469c4031c4d9cb391f0224e9d97e234893bdbfcda19a6fc3->leave($__internal_987156d34759998e469c4031c4d9cb391f0224e9d97e234893bdbfcda19a6fc3_prof);

    }

    // line 3
    public function block_linkElement($context, array $blocks = array())
    {
        $__internal_40b8bab11952f2c603b769ee128ae6fd696cddac921091977d23929ca936abb9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40b8bab11952f2c603b769ee128ae6fd696cddac921091977d23929ca936abb9->enter($__internal_40b8bab11952f2c603b769ee128ae6fd696cddac921091977d23929ca936abb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "linkElement"));

        $__internal_e41720c22c72f1130431a2784532ecffa54122a8670d4da124563424f1e5e767 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e41720c22c72f1130431a2784532ecffa54122a8670d4da124563424f1e5e767->enter($__internal_e41720c22c72f1130431a2784532ecffa54122a8670d4da124563424f1e5e767_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "linkElement"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        $context["macros"] = $this->loadTemplate("knp_menu.html.twig", "MopaBootstrapBundle:Menu:menu.html.twig", 5);
        // line 6
        echo "        <a href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "uri", array()), "html", null, true);
        echo "\"";
        echo $context["macros"]->getattributes($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "linkAttributes", array()));
        echo ">
            ";
        // line 7
        if ((($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "icon", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "icon", array()), false)) : (false))) {
            // line 8
            echo "                ";
            echo $this->env->getExtension('Mopa\Bundle\BootstrapBundle\Twig\IconExtension')->renderIcon($this->env, $this->getAttribute($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "extras", array()), "icon", array()), (($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "icon_white", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "icon_white", array()), false)) : (false)));
            echo " ";
        }
        // line 10
        echo "            ";
        $this->displayBlock("label", $context, $blocks);
        echo "
            ";
        // line 11
        $context["badgemacro"] = $this->loadTemplate("MopaBootstrapBundle::macros.html.twig", "MopaBootstrapBundle:Menu:menu.html.twig", 11);
        // line 12
        if ((($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "badge", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "badge", array()), false)) : (false))) {
            // line 13
            echo "                ";
            echo $context["badgemacro"]->getbadge($this->getAttribute($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "extras", array()), "badge", array()), false, $this->getAttribute($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "extras", array()), "badge_class", array()));
            echo "
            ";
        }
        // line 15
        if ((($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "caret", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["item"] ?? null), "extras", array(), "any", false, true), "caret", array()), false)) : (false))) {
            // line 16
            echo "                <b class=\"caret\"></b>
            ";
        }
        // line 18
        echo "</a>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_e41720c22c72f1130431a2784532ecffa54122a8670d4da124563424f1e5e767->leave($__internal_e41720c22c72f1130431a2784532ecffa54122a8670d4da124563424f1e5e767_prof);

        
        $__internal_40b8bab11952f2c603b769ee128ae6fd696cddac921091977d23929ca936abb9->leave($__internal_40b8bab11952f2c603b769ee128ae6fd696cddac921091977d23929ca936abb9_prof);

    }

    public function getTemplateName()
    {
        return "MopaBootstrapBundle:Menu:menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 18,  86 => 16,  84 => 15,  78 => 13,  76 => 12,  74 => 11,  69 => 10,  64 => 8,  62 => 7,  55 => 6,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'KnpMenuBundle::menu.html.twig' %}

{% block linkElement %}
    {% spaceless %}
        {% import 'knp_menu.html.twig' as macros %}
        <a href=\"{{ item.uri }}\"{{ macros.attributes(item.linkAttributes) }}>
            {% if item.extras.icon|default(false) %}
                {{ mopa_bootstrap_icon(item.extras.icon, item.extras.icon_white|default(false)) }}{{ ' ' }}
            {%- endif %}
            {{ block('label') }}
            {% import 'MopaBootstrapBundle::macros.html.twig' as badgemacro %}
            {%- if item.extras.badge|default(false) %}
                {{ badgemacro.badge(item.extras.badge, false, item.extras.badge_class) }}
            {% endif -%}
            {%- if item.extras.caret|default(false) %}
                <b class=\"caret\"></b>
            {% endif -%}
        </a>
    {% endspaceless %}
{% endblock %}
", "MopaBootstrapBundle:Menu:menu.html.twig", "/home/henne/Desktop/Project/opium/vendor/mopa/bootstrap-bundle/Mopa/Bundle/BootstrapBundle/Resources/views/Menu/menu.html.twig");
    }
}
