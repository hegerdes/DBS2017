<?php

/* KnpMenuBundle::menu.html.twig */
class __TwigTemplate_e9d07a999e0701d9185fb31c9a2f1e830357f50c0bc36389fca4220c80d6d17e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("knp_menu.html.twig", "KnpMenuBundle::menu.html.twig", 1);
        $this->blocks = array(
            'label' => array($this, 'block_label'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "knp_menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c8d122f51e178914ae8a7f44e3bb4667f07a77a41273e2842dff9b1f913e3c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c8d122f51e178914ae8a7f44e3bb4667f07a77a41273e2842dff9b1f913e3c8->enter($__internal_2c8d122f51e178914ae8a7f44e3bb4667f07a77a41273e2842dff9b1f913e3c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "KnpMenuBundle::menu.html.twig"));

        $__internal_ed729a65af59aece1e29b62b73fa2870238f7d1adcaef8cb1c4202ce31d3f085 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed729a65af59aece1e29b62b73fa2870238f7d1adcaef8cb1c4202ce31d3f085->enter($__internal_ed729a65af59aece1e29b62b73fa2870238f7d1adcaef8cb1c4202ce31d3f085_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "KnpMenuBundle::menu.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2c8d122f51e178914ae8a7f44e3bb4667f07a77a41273e2842dff9b1f913e3c8->leave($__internal_2c8d122f51e178914ae8a7f44e3bb4667f07a77a41273e2842dff9b1f913e3c8_prof);

        
        $__internal_ed729a65af59aece1e29b62b73fa2870238f7d1adcaef8cb1c4202ce31d3f085->leave($__internal_ed729a65af59aece1e29b62b73fa2870238f7d1adcaef8cb1c4202ce31d3f085_prof);

    }

    // line 3
    public function block_label($context, array $blocks = array())
    {
        $__internal_8318f3c30c7a2c9cda6b2429697a4936a023229c92bb48f32e7a5903fd820f3e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8318f3c30c7a2c9cda6b2429697a4936a023229c92bb48f32e7a5903fd820f3e->enter($__internal_8318f3c30c7a2c9cda6b2429697a4936a023229c92bb48f32e7a5903fd820f3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "label"));

        $__internal_fa17c70d928062d4645a15d5d2fd7c3f2a981b840e907baa170bc9cb0d23419b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa17c70d928062d4645a15d5d2fd7c3f2a981b840e907baa170bc9cb0d23419b->enter($__internal_fa17c70d928062d4645a15d5d2fd7c3f2a981b840e907baa170bc9cb0d23419b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "label"));

        // line 4
        $context["translation_domain"] = $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "extra", array(0 => "translation_domain", 1 => "messages"), "method");
        // line 5
        $context["label"] = $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "label", array());
        // line 6
        if ( !(($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) {
            // line 7
            $context["label"] = $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "extra", array(0 => "translation_params", 1 => array()), "method"), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")));
        }
        // line 9
        if (($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "allow_safe_labels", array()) && $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "extra", array(0 => "safe_label", 1 => false), "method"))) {
            echo ($context["label"] ?? $this->getContext($context, "label"));
        } else {
            echo twig_escape_filter($this->env, ($context["label"] ?? $this->getContext($context, "label")), "html", null, true);
        }
        
        $__internal_fa17c70d928062d4645a15d5d2fd7c3f2a981b840e907baa170bc9cb0d23419b->leave($__internal_fa17c70d928062d4645a15d5d2fd7c3f2a981b840e907baa170bc9cb0d23419b_prof);

        
        $__internal_8318f3c30c7a2c9cda6b2429697a4936a023229c92bb48f32e7a5903fd820f3e->leave($__internal_8318f3c30c7a2c9cda6b2429697a4936a023229c92bb48f32e7a5903fd820f3e_prof);

    }

    public function getTemplateName()
    {
        return "KnpMenuBundle::menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 9,  55 => 7,  53 => 6,  51 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'knp_menu.html.twig' %}

{% block label %}
    {%- set translation_domain = item.extra('translation_domain', 'messages') -%}
    {%- set label = item.label -%}
    {%- if translation_domain is not same as(false) -%}
        {%- set label = label|trans(item.extra('translation_params', {}), translation_domain) -%}
    {%- endif -%}
    {%- if options.allow_safe_labels and item.extra('safe_label', false) %}{{ label|raw }}{% else %}{{ label }}{% endif -%}
{% endblock %}
", "KnpMenuBundle::menu.html.twig", "/home/henne/Desktop/Project/opium/vendor/knplabs/knp-menu-bundle/Resources/views/menu.html.twig");
    }
}
