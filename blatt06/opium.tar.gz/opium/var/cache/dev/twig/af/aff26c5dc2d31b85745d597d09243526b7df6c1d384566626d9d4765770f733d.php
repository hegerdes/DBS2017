<?php

/* OpiumBundle:Examiner:detail.html.twig */
class __TwigTemplate_cc471fe4ee96b38b4612637a38f18682372a486df291dc681d20862bcb3d9d06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "OpiumBundle:Examiner:detail.html.twig", 1);
        $this->blocks = array(
            'headline' => array($this, 'block_headline'),
            'title' => array($this, 'block_title'),
            'content_row' => array($this, 'block_content_row'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_50be6e7cd375fff427090d3348691212bd1dc348e2db7961bafb462062a913c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50be6e7cd375fff427090d3348691212bd1dc348e2db7961bafb462062a913c9->enter($__internal_50be6e7cd375fff427090d3348691212bd1dc348e2db7961bafb462062a913c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OpiumBundle:Examiner:detail.html.twig"));

        $__internal_1257941b13fad6b9f3e98abc130c72236665914d23b285283c2e42b046f0a1da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1257941b13fad6b9f3e98abc130c72236665914d23b285283c2e42b046f0a1da->enter($__internal_1257941b13fad6b9f3e98abc130c72236665914d23b285283c2e42b046f0a1da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OpiumBundle:Examiner:detail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_50be6e7cd375fff427090d3348691212bd1dc348e2db7961bafb462062a913c9->leave($__internal_50be6e7cd375fff427090d3348691212bd1dc348e2db7961bafb462062a913c9_prof);

        
        $__internal_1257941b13fad6b9f3e98abc130c72236665914d23b285283c2e42b046f0a1da->leave($__internal_1257941b13fad6b9f3e98abc130c72236665914d23b285283c2e42b046f0a1da_prof);

    }

    // line 3
    public function block_headline($context, array $blocks = array())
    {
        $__internal_067c70f494b45f67f1ce72eab29942294d64f484fe4d1f3d83f280901582e8bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_067c70f494b45f67f1ce72eab29942294d64f484fe4d1f3d83f280901582e8bd->enter($__internal_067c70f494b45f67f1ce72eab29942294d64f484fe4d1f3d83f280901582e8bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        $__internal_7478ab38cee49a9dee900174de6f3af326b3c7ac03375b03263984fb10a9c399 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7478ab38cee49a9dee900174de6f3af326b3c7ac03375b03263984fb10a9c399->enter($__internal_7478ab38cee49a9dee900174de6f3af326b3c7ac03375b03263984fb10a9c399_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "headline"));

        // line 4
        echo "Übersicht zur Prüfung
";
        
        $__internal_7478ab38cee49a9dee900174de6f3af326b3c7ac03375b03263984fb10a9c399->leave($__internal_7478ab38cee49a9dee900174de6f3af326b3c7ac03375b03263984fb10a9c399_prof);

        
        $__internal_067c70f494b45f67f1ce72eab29942294d64f484fe4d1f3d83f280901582e8bd->leave($__internal_067c70f494b45f67f1ce72eab29942294d64f484fe4d1f3d83f280901582e8bd_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_5c71de88b91f9ed86a66ccdf43f9e1f30551053b73f14c301fb8be4bda82030e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c71de88b91f9ed86a66ccdf43f9e1f30551053b73f14c301fb8be4bda82030e->enter($__internal_5c71de88b91f9ed86a66ccdf43f9e1f30551053b73f14c301fb8be4bda82030e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_c086a0f6d424acfdfd8cf496a3f81346a7814ea59760a1c2f1c49959c9f3d770 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c086a0f6d424acfdfd8cf496a3f81346a7814ea59760a1c2f1c49959c9f3d770->enter($__internal_c086a0f6d424acfdfd8cf496a3f81346a7814ea59760a1c2f1c49959c9f3d770_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    Übersicht zur Prüfung \"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exam"] ?? $this->getContext($context, "exam")), "subject", array()), "html", null, true);
        echo "\"
";
        
        $__internal_c086a0f6d424acfdfd8cf496a3f81346a7814ea59760a1c2f1c49959c9f3d770->leave($__internal_c086a0f6d424acfdfd8cf496a3f81346a7814ea59760a1c2f1c49959c9f3d770_prof);

        
        $__internal_5c71de88b91f9ed86a66ccdf43f9e1f30551053b73f14c301fb8be4bda82030e->leave($__internal_5c71de88b91f9ed86a66ccdf43f9e1f30551053b73f14c301fb8be4bda82030e_prof);

    }

    // line 11
    public function block_content_row($context, array $blocks = array())
    {
        $__internal_e11174a0545b11e4b71d89c462e8a811005bdfd9b9f8c8e1f368c286913b26d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e11174a0545b11e4b71d89c462e8a811005bdfd9b9f8c8e1f368c286913b26d0->enter($__internal_e11174a0545b11e4b71d89c462e8a811005bdfd9b9f8c8e1f368c286913b26d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        $__internal_5b2542318cb95589a8234a3c5b7851fd84e7dbf2a4eb882e42f5f9abd9dfc724 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b2542318cb95589a8234a3c5b7851fd84e7dbf2a4eb882e42f5f9abd9dfc724->enter($__internal_5b2542318cb95589a8234a3c5b7851fd84e7dbf2a4eb882e42f5f9abd9dfc724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_row"));

        // line 12
        echo "

    <h2>Prüfung</h2>

    <div class=\"row\">
        <div class=\"col-sm-12\"><strong>Thema:</strong>&nbsp;";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exam"] ?? $this->getContext($context, "exam")), "subject", array()), "html", null, true);
        echo "</div>
        <div class=\"col-sm-12\"><strong>Semester:</strong>&nbsp;";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["exam"] ?? $this->getContext($context, "exam")), "semester", array()), "identifier", array()), "html", null, true);
        echo "</div>
        <div class=\"col-sm-12\"><strong>Datum:</strong>&nbsp;";
        // line 19
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["exam"] ?? $this->getContext($context, "exam")), "date", array()), "d.m.Y"), "html", null, true);
        echo "</div>
        <div class=\"col-sm-12\"><strong>Uhrzeit:</strong>&nbsp;";
        // line 20
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["exam"] ?? $this->getContext($context, "exam")), "date", array()), "H:i"), "html", null, true);
        echo "</div>
        <div class=\"col-sm-12\"><strong>Termin:</strong>&nbsp;";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exam"] ?? $this->getContext($context, "exam")), "appointment", array()), "html", null, true);
        echo "</div>
    </div>

    <h2>Teilnehmer</h2>

    <table class=\"table table-condensed\">
        <thead>
        <tr>
            <th>Vorname</th>
            <th>Nachname</th>
            <th>Matrikelnummer</th>
            <th>E-Mail</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["students"] ?? $this->getContext($context, "students")));
        foreach ($context['_seq'] as $context["_key"] => $context["student"]) {
            // line 37
            echo "
            <tr>
                <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "forename", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "surname", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "matriculationNumber", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "email", array()), "html", null, true);
            echo "</td>
            </tr>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['student'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "        </tbody>
    </table>


";
        
        $__internal_5b2542318cb95589a8234a3c5b7851fd84e7dbf2a4eb882e42f5f9abd9dfc724->leave($__internal_5b2542318cb95589a8234a3c5b7851fd84e7dbf2a4eb882e42f5f9abd9dfc724_prof);

        
        $__internal_e11174a0545b11e4b71d89c462e8a811005bdfd9b9f8c8e1f368c286913b26d0->leave($__internal_e11174a0545b11e4b71d89c462e8a811005bdfd9b9f8c8e1f368c286913b26d0_prof);

    }

    public function getTemplateName()
    {
        return "OpiumBundle:Examiner:detail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 46,  154 => 42,  150 => 41,  146 => 40,  142 => 39,  138 => 37,  134 => 36,  116 => 21,  112 => 20,  108 => 19,  104 => 18,  100 => 17,  93 => 12,  84 => 11,  71 => 8,  62 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block headline %}
Übersicht zur Prüfung
{% endblock %}

{% block title %}
    Übersicht zur Prüfung \"{{ exam.subject }}\"
{% endblock %}

{% block content_row %}


    <h2>Prüfung</h2>

    <div class=\"row\">
        <div class=\"col-sm-12\"><strong>Thema:</strong>&nbsp;{{ exam.subject }}</div>
        <div class=\"col-sm-12\"><strong>Semester:</strong>&nbsp;{{ exam.semester.identifier }}</div>
        <div class=\"col-sm-12\"><strong>Datum:</strong>&nbsp;{{ exam.date|date('d.m.Y') }}</div>
        <div class=\"col-sm-12\"><strong>Uhrzeit:</strong>&nbsp;{{ exam.date|date('H:i') }}</div>
        <div class=\"col-sm-12\"><strong>Termin:</strong>&nbsp;{{ exam.appointment }}</div>
    </div>

    <h2>Teilnehmer</h2>

    <table class=\"table table-condensed\">
        <thead>
        <tr>
            <th>Vorname</th>
            <th>Nachname</th>
            <th>Matrikelnummer</th>
            <th>E-Mail</th>
        </tr>
        </thead>
        <tbody>
        {% for student in students %}

            <tr>
                <td>{{ student.forename }}</td>
                <td>{{ student.surname }}</td>
                <td>{{ student.matriculationNumber }}</td>
                <td>{{ student.email }}</td>
            </tr>

        {% endfor %}
        </tbody>
    </table>


{% endblock content_row %}
", "OpiumBundle:Examiner:detail.html.twig", "/home/henne/Desktop/Project/opium/src/OpiumBundle/Resources/views/Examiner/detail.html.twig");
    }
}
